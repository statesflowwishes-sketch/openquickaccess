# PLOT – Build‑Up Starter Kit (Sandbox + Secure App Launch)
This repo is a **hands‑on build‑up** for your self‑built cloud sandbox. It bootstraps:
- IaC skeleton (Terraform/Helm hooks),
- a minimal Kubernetes baseline with **guardrails** (RBAC, NetworkPolicy, Kyverno),
- a hardened **Hello‑Universe** app deployment,
- a **Launch API** spec + Postman collection,
- local Docker Compose mirror for quick tests.

## Quickstart (local mirror)
```bash
# 1) bring up local mirror services
docker compose up -d

# 2) seed example (optional)
make seed-kpi

# 3) launch the sample app (Kubernetes) – requires a cluster + kubectl context
make k8s-bootstrap
make launch
```

## Deploy sandbox (cloud) – outline
```bash
# 1) Provision base infra (VPC/K8s/etc) using your cloud account
make sandbox

# 2) Bootstrap policies and namespaces
make k8s-bootstrap

# 3) Deploy the sample app and expose via Ingress + OIDC
make launch
```

> Guardrails: signed images, least privilege, default‑deny network, mTLS (via your mesh), and
> reproducibility through GitOps‑friendly files.

---

### What’s inside
- `infra/` – Terraform stubs for a sandbox environment
- `k8s/` – Namespaces, quotas, NetworkPolicies, Kyverno policy, hardened Deployment + Ingress
- `api/` – OpenAPI spec for a minimal Launch API + Postman collection
- `examples/specs/` – JSON payload for `/api/launch/run`
- `security/policies/opa/` – sample OPA (Rego) rule
- `.github/workflows/` – CI step to build, SBOM, scan, sign

**Note:** Replace placeholders like `registry.example` and domain names with your own.
