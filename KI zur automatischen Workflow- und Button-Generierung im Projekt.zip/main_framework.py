#!/usr/bin/env python3
"""
Main Framework for Automatic Code Analysis and Button Generation
"""

import os
import sys
import json
import argparse
from pathlib import Path

# Import our modules
from code_analyzer import CodeAnalyzer
from button_generator import ButtonGenerator
from code_injector import CodeInjector
from file_detector import FileDetector, UserLocationDetector

class AutoCodeFramework:
    def __init__(self, project_path):
        self.project_path = os.path.abspath(project_path)
        self.output_dir = os.path.join(self.project_path, '.auto_framework')
        
        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)
        
        # Initialize components
        self.code_analyzer = CodeAnalyzer(self.project_path)
        self.file_detector = FileDetector(self.project_path)
        self.user_detector = UserLocationDetector(self.project_path)
        
        # Results storage
        self.analysis_results = {}
        self.file_detection_results = {}
        self.generated_files = []

    def analyze_project(self):
        """
        Perform comprehensive project analysis.
        """
        print(f"Analyzing project: {self.project_path}")
        
        # Analyze code structure
        print("  - Analyzing code structure...")
        self.code_analyzer.analyze_project()
        self.analysis_results = self.code_analyzer.get_analysis_results()
        
        # Detect file types and user locations
        print("  - Detecting file types...")
        self.file_detector.detect_file_types()
        self.file_detection_results = self.file_detector.get_detection_results()
        
        # Detect user workspaces
        print("  - Detecting user workspaces...")
        workspaces = self.user_detector.detect_user_workspace()
        entry_points = self.user_detector.detect_entry_points()
        
        self.file_detection_results['workspaces'] = workspaces
        self.file_detection_results['entry_points'] = entry_points
        
        # Save analysis results
        analysis_file = os.path.join(self.output_dir, 'analysis_results.json')
        with open(analysis_file, 'w') as f:
            json.dump({
                'code_analysis': self.analysis_results,
                'file_detection': self.file_detection_results
            }, f, indent=2)
        
        self.generated_files.append(analysis_file)
        print(f"  - Analysis results saved to: {analysis_file}")

    def generate_interface(self):
        """
        Generate buttons and interface based on analysis.
        """
        print("Generating interface components...")
        
        # Generate buttons
        button_generator = ButtonGenerator(self.analysis_results)
        buttons = button_generator.generate_buttons()
        
        # Generate HTML interface
        interface_file = os.path.join(self.output_dir, 'interface.html')
        button_generator.generate_html_interface(interface_file)
        self.generated_files.append(interface_file)
        print(f"  - HTML interface generated: {interface_file}")
        
        # Generate workflow configuration
        config_file = os.path.join(self.output_dir, 'workflow_config.json')
        button_generator.generate_workflow_config(config_file)
        self.generated_files.append(config_file)
        print(f"  - Workflow config generated: {config_file}")
        
        return buttons, config_file

    def inject_handlers(self, workflow_config_file):
        """
        Inject button handlers and create API.
        """
        print("Injecting button handlers...")
        
        # Load workflow config
        with open(workflow_config_file, 'r') as f:
            workflow_config = json.load(f)
        
        # Create code injector
        injector = CodeInjector(self.output_dir)
        
        # Generate handlers
        handler_file = injector.inject_button_handlers(workflow_config)
        self.generated_files.append(handler_file)
        print(f"  - Button handlers generated: {handler_file}")
        
        # Generate Flask API
        api_file = injector.create_flask_api(workflow_config)
        self.generated_files.append(api_file)
        print(f"  - Flask API generated: {api_file}")
        
        return handler_file, api_file

    def create_startup_script(self):
        """
        Create a startup script to run the generated interface.
        """
        startup_script = os.path.join(self.output_dir, 'start_interface.py')
        
        script_content = f"""#!/usr/bin/env python3
\"\"\"
Startup script for the auto-generated interface
\"\"\"

import os
import sys
import webbrowser
import time
from threading import Timer

# Add the framework directory to Python path
framework_dir = os.path.dirname(os.path.abspath(__file__))
if framework_dir not in sys.path:
    sys.path.insert(0, framework_dir)

def open_browser():
    \"\"\"Open the interface in the default browser\"\"\"
    webbrowser.open('http://localhost:5000')

def main():
    print("Starting Auto-Generated Code Interface...")
    print(f"Framework directory: {{framework_dir}}")
    print("Interface will be available at: http://localhost:5000")
    
    # Open browser after a short delay
    Timer(2.0, open_browser).start()
    
    # Start the Flask server
    try:
        from api_server import app
        app.run(host='0.0.0.0', port=5000, debug=False)
    except ImportError as e:
        print(f"Error importing API server: {{e}}")
        print("Make sure all components are properly generated.")
        sys.exit(1)
    except Exception as e:
        print(f"Error starting server: {{e}}")
        sys.exit(1)

if __name__ == '__main__':
    main()
"""
        
        with open(startup_script, 'w') as f:
            f.write(script_content)
        
        # Make it executable
        os.chmod(startup_script, 0o755)
        self.generated_files.append(startup_script)
        print(f"  - Startup script created: {startup_script}")
        
        return startup_script

    def run_full_analysis(self):
        """
        Run the complete framework analysis and generation process.
        """
        print("=" * 60)
        print("AUTO CODE FRAMEWORK - FULL ANALYSIS")
        print("=" * 60)
        
        try:
            # Step 1: Analyze project
            self.analyze_project()
            
            # Step 2: Generate interface
            buttons, config_file = self.generate_interface()
            
            # Step 3: Inject handlers
            handler_file, api_file = self.inject_handlers(config_file)
            
            # Step 4: Create startup script
            startup_script = self.create_startup_script()
            
            # Step 5: Generate summary
            self.generate_summary()
            
            print("=" * 60)
            print("FRAMEWORK GENERATION COMPLETED SUCCESSFULLY!")
            print("=" * 60)
            print(f"Generated {len(self.generated_files)} files in: {self.output_dir}")
            print(f"To start the interface, run: python3 {startup_script}")
            
            return True
            
        except Exception as e:
            print(f"Error during framework generation: {e}")
            import traceback
            traceback.print_exc()
            return False

    def generate_summary(self):
        """
        Generate a summary report of the analysis and generation process.
        """
        summary = {
            'project_path': self.project_path,
            'output_directory': self.output_dir,
            'generated_files': self.generated_files,
            'analysis_summary': {
                'total_modules': len(self.analysis_results.get('modules', [])),
                'total_functions': len(self.analysis_results.get('functions', [])),
                'total_classes': len(self.analysis_results.get('classes', [])),
                'identified_workflows': len(self.analysis_results.get('workflows', []))
            },
            'file_detection_summary': self.file_detection_results.get('summary', {}),
            'instructions': [
                f"1. Navigate to: {self.output_dir}",
                "2. Run: python3 start_interface.py",
                "3. Open browser to: http://localhost:5000",
                "4. Use the auto-generated buttons to interact with your code"
            ]
        }
        
        summary_file = os.path.join(self.output_dir, 'framework_summary.json')
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        self.generated_files.append(summary_file)
        print(f"  - Summary report generated: {summary_file}")

def main():
    parser = argparse.ArgumentParser(description='Auto Code Framework - Analyze and generate interfaces for codebases')
    parser.add_argument('project_path', help='Path to the project directory to analyze')
    parser.add_argument('--output-dir', help='Custom output directory (default: PROJECT_PATH/.auto_framework)')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.project_path):
        print(f"Error: Project path does not exist: {args.project_path}")
        sys.exit(1)
    
    # Initialize framework
    framework = AutoCodeFramework(args.project_path)
    
    if args.output_dir:
        framework.output_dir = os.path.abspath(args.output_dir)
        os.makedirs(framework.output_dir, exist_ok=True)
    
    # Run analysis
    success = framework.run_full_analysis()
    
    if success:
        print("\\nFramework ready! Check the generated files and run the startup script.")
    else:
        print("\\nFramework generation failed. Check the error messages above.")
        sys.exit(1)

if __name__ == '__main__':
    main()

