import os
import mimetypes
from pathlib import Path
import json

class FileDetector:
    def __init__(self, project_path):
        self.project_path = project_path
        self.user_files = []
        self.system_files = []
        self.config_files = []
        self.source_files = []

    def detect_file_types(self):
        """
        Detect and categorize different types of files in the project.
        """
        for root, dirs, files in os.walk(self.project_path):
            # Skip common system/hidden directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['__pycache__', 'node_modules', 'venv', 'env']]
            
            for file in files:
                filepath = os.path.join(root, file)
                relative_path = os.path.relpath(filepath, self.project_path)
                
                file_info = {
                    'path': filepath,
                    'relative_path': relative_path,
                    'name': file,
                    'size': os.path.getsize(filepath),
                    'extension': Path(file).suffix.lower(),
                    'mime_type': mimetypes.guess_type(filepath)[0]
                }
                
                # Categorize files
                if self._is_user_file(file_info):
                    self.user_files.append(file_info)
                elif self._is_config_file(file_info):
                    self.config_files.append(file_info)
                elif self._is_source_file(file_info):
                    self.source_files.append(file_info)
                else:
                    self.system_files.append(file_info)

    def _is_user_file(self, file_info):
        """
        Determine if a file is likely a user-created content file.
        """
        user_extensions = ['.txt', '.md', '.doc', '.docx', '.pdf', '.jpg', '.jpeg', '.png', '.gif', '.mp4', '.mp3']
        user_patterns = ['readme', 'todo', 'notes', 'data', 'input', 'output']
        
        if file_info['extension'] in user_extensions:
            return True
        
        filename_lower = file_info['name'].lower()
        for pattern in user_patterns:
            if pattern in filename_lower:
                return True
        
        return False

    def _is_config_file(self, file_info):
        """
        Determine if a file is a configuration file.
        """
        config_extensions = ['.json', '.yaml', '.yml', '.toml', '.ini', '.cfg', '.conf']
        config_names = ['package.json', 'requirements.txt', 'setup.py', 'dockerfile', 'makefile', '.gitignore', '.env']
        
        if file_info['extension'] in config_extensions:
            return True
        
        filename_lower = file_info['name'].lower()
        if filename_lower in config_names:
            return True
        
        return False

    def _is_source_file(self, file_info):
        """
        Determine if a file is a source code file.
        """
        source_extensions = ['.py', '.js', '.ts', '.html', '.css', '.java', '.cpp', '.c', '.h', '.go', '.rs', '.php', '.rb']
        
        return file_info['extension'] in source_extensions

    def find_user_data_files(self):
        """
        Find files that likely contain user data or input.
        """
        data_files = []
        data_extensions = ['.csv', '.json', '.xml', '.xlsx', '.txt', '.dat']
        data_keywords = ['data', 'input', 'dataset', 'sample', 'test', 'example']
        
        for file_info in self.user_files + self.config_files:
            if (file_info['extension'] in data_extensions or 
                any(keyword in file_info['name'].lower() for keyword in data_keywords)):
                data_files.append(file_info)
        
        return data_files

    def get_project_structure(self):
        """
        Get a hierarchical view of the project structure.
        """
        structure = {}
        
        for file_info in self.user_files + self.config_files + self.source_files + self.system_files:
            path_parts = file_info['relative_path'].split(os.sep)
            current = structure
            
            for part in path_parts[:-1]:  # Directories
                if part not in current:
                    current[part] = {}
                current = current[part]
            
            # File
            filename = path_parts[-1]
            current[filename] = {
                'type': 'file',
                'info': file_info
            }
        
        return structure

    def get_detection_results(self):
        """
        Get comprehensive file detection results.
        """
        return {
            'user_files': self.user_files,
            'config_files': self.config_files,
            'source_files': self.source_files,
            'system_files': self.system_files,
            'data_files': self.find_user_data_files(),
            'project_structure': self.get_project_structure(),
            'summary': {
                'total_files': len(self.user_files) + len(self.config_files) + len(self.source_files) + len(self.system_files),
                'user_files_count': len(self.user_files),
                'config_files_count': len(self.config_files),
                'source_files_count': len(self.source_files),
                'system_files_count': len(self.system_files)
            }
        }

class UserLocationDetector:
    def __init__(self, project_path):
        self.project_path = project_path

    def detect_user_workspace(self):
        """
        Detect where the user typically works within the project.
        """
        # Look for common user workspace indicators
        workspace_indicators = [
            'src/', 'source/', 'app/', 'lib/', 'main/',
            'scripts/', 'tools/', 'utils/', 'examples/',
            'notebooks/', 'data/', 'docs/', 'documentation/'
        ]
        
        detected_workspaces = []
        
        for root, dirs, files in os.walk(self.project_path):
            relative_root = os.path.relpath(root, self.project_path)
            
            # Check if this directory matches workspace patterns
            for indicator in workspace_indicators:
                if indicator.rstrip('/') in relative_root.split(os.sep):
                    detected_workspaces.append({
                        'path': root,
                        'relative_path': relative_root,
                        'type': indicator.rstrip('/'),
                        'file_count': len(files)
                    })
                    break
        
        return detected_workspaces

    def detect_entry_points(self):
        """
        Detect likely entry points where users start working.
        """
        entry_point_names = ['main.py', 'app.py', 'index.py', 'run.py', 'start.py', 'server.py']
        entry_points = []
        
        for root, dirs, files in os.walk(self.project_path):
            for file in files:
                if file in entry_point_names:
                    filepath = os.path.join(root, file)
                    entry_points.append({
                        'path': filepath,
                        'relative_path': os.path.relpath(filepath, self.project_path),
                        'name': file,
                        'priority': entry_point_names.index(file)  # Lower index = higher priority
                    })
        
        # Sort by priority
        entry_points.sort(key=lambda x: x['priority'])
        return entry_points

if __name__ == '__main__':
    # Test with the current framework directory
    detector = FileDetector('/home/ubuntu/code_analysis_framework')
    detector.detect_file_types()
    results = detector.get_detection_results()
    
    print("File Detection Results:")
    print(json.dumps(results['summary'], indent=2))
    
    user_detector = UserLocationDetector('/home/ubuntu/code_analysis_framework')
    workspaces = user_detector.detect_user_workspace()
    entry_points = user_detector.detect_entry_points()
    
    print("\nDetected Workspaces:")
    for workspace in workspaces:
        print(f"  {workspace['relative_path']} ({workspace['type']})")
    
    print("\nDetected Entry Points:")
    for entry_point in entry_points:
        print(f"  {entry_point['relative_path']}")

