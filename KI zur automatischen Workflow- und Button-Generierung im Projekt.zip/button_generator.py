import json
import os

class ButtonGenerator:
    def __init__(self, analysis_results):
        self.analysis_results = analysis_results
        self.buttons = []

    def generate_buttons(self):
        # Generate buttons for identified workflows
        for workflow in self.analysis_results.get('workflows', []):
            button = {
                'id': f"btn_{workflow['name']}",
                'label': workflow['name'].replace('_', ' ').title(),
                'action': workflow['name'],
                'type': workflow['type'],
                'description': workflow['description']
            }
            self.buttons.append(button)

        # Generate buttons for standalone functions
        for func in self.analysis_results.get('functions', []):
            if func['name'] not in [w['name'] for w in self.analysis_results.get('workflows', [])]:
                button = {
                    'id': f"btn_{func['name']}",
                    'label': func['name'].replace('_', ' ').title(),
                    'action': func['name'],
                    'type': 'function',
                    'description': f"Execute function: {func['name']}"
                }
                self.buttons.append(button)

        return self.buttons

    def generate_html_interface(self, output_path):
        html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Code Analysis Framework - Auto-Generated Interface</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .button-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .btn {
            padding: 15px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
            text-align: center;
        }
        .btn-entry_point {
            background-color: #4CAF50;
            color: white;
        }
        .btn-orchestrator {
            background-color: #2196F3;
            color: white;
        }
        .btn-function {
            background-color: #FF9800;
            color: white;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .description {
            font-size: 12px;
            margin-top: 5px;
            opacity: 0.8;
        }
        .status {
            margin-top: 20px;
            padding: 10px;
            background-color: #e8f5e8;
            border-radius: 5px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Auto-Generated Code Interface</h1>
        <p>This interface was automatically generated based on your codebase analysis.</p>
        
        <div class="button-grid">
"""

        for button in self.buttons:
            html_content += f"""
            <button class="btn btn-{button['type']}" onclick="executeAction('{button['action']}')">
                <div>{button['label']}</div>
                <div class="description">{button['description']}</div>
            </button>
"""

        html_content += """
        </div>
        
        <div id="status" class="status"></div>
    </div>

    <script>
        function executeAction(action) {
            const statusDiv = document.getElementById('status');
            statusDiv.style.display = 'block';
            statusDiv.innerHTML = `Executing: ${action}...`;
            
            // In a real implementation, this would make an API call to execute the function
            // For now, we'll just simulate the execution
            setTimeout(() => {
                statusDiv.innerHTML = `Successfully executed: ${action}`;
                statusDiv.style.backgroundColor = '#e8f5e8';
            }, 1000);
        }
    </script>
</body>
</html>
"""

        with open(output_path, 'w') as f:
            f.write(html_content)

    def generate_workflow_config(self, output_path):
        workflow_config = {
            'buttons': self.buttons,
            'workflows': self.analysis_results.get('workflows', []),
            'functions': self.analysis_results.get('functions', []),
            'dependencies': self.analysis_results.get('dependencies', {})
        }
        
        with open(output_path, 'w') as f:
            json.dump(workflow_config, f, indent=2)

if __name__ == '__main__':
    # Test with dummy data
    dummy_analysis = {
        'functions': [
            {'name': 'func_a', 'file': 'main.py', 'lineno': 1},
            {'name': 'func_b', 'file': 'main.py', 'lineno': 5}
        ],
        'workflows': [
            {'type': 'entry_point', 'name': 'func_a', 'description': 'Entry point function'},
            {'type': 'orchestrator', 'name': 'func_b', 'description': 'Orchestrator function'}
        ],
        'dependencies': {'func_a': ['func_b']}
    }
    
    generator = ButtonGenerator(dummy_analysis)
    buttons = generator.generate_buttons()
    print("Generated buttons:", buttons)
    
    generator.generate_html_interface('/home/ubuntu/code_analysis_framework/test_interface.html')
    generator.generate_workflow_config('/home/ubuntu/code_analysis_framework/workflow_config.json')

