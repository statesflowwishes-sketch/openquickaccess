# Auto-generated Flask API for button handlers
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

# Add the project path to sys.path
project_path = os.path.dirname(os.path.abspath(__file__))
if project_path not in sys.path:
    sys.path.append(project_path)

from auto_generated_handlers import execute_button_action

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/actions', methods=['GET'])
def get_available_actions():
    """Get list of available actions"""
    from auto_generated_handlers import button_handlers
    actions = list(button_handlers.handlers.keys())
    return jsonify({'actions': actions})

@app.route('/api/execute/<action_name>', methods=['POST'])
def execute_action(action_name):
    """Execute a specific action"""
    try:
        data = request.get_json() or {}
        args = data.get('args', [])
        kwargs = data.get('kwargs', {})
        
        result = execute_button_action(action_name, *args, **kwargs)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e), 'action': action_name}), 500

@app.route('/api/workflow-config', methods=['GET'])
def get_workflow_config():
    """Get the workflow configuration"""
    try:
        import json
        with open('workflow_config.json', 'r') as f:
            config = json.load(f)
        return jsonify(config)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def index():
    """Serve the main interface"""
    try:
        with open('interface.html', 'r') as f:
            return f.read()
    except FileNotFoundError:
        return "Interface not found. Please generate the HTML interface first.", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
