
import ast
import os
from collections import defaultdict

class CodeAnalyzer:
    def __init__(self, project_path):
        self.project_path = project_path
        self.functions = []
        self.classes = []
        self.modules = []
        self.dependencies = defaultdict(list) # {caller: [callee1, callee2, ...]}

    def analyze_file(self, filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        try:
            tree = ast.parse(content)
            self.modules.append(filepath)

            current_function = None
            current_class = None

            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    self.functions.append({'name': node.name, 'file': filepath, 'lineno': node.lineno})
                    current_function = node.name
                    current_class = None # Reset current class when a function is found at module level
                elif isinstance(node, ast.ClassDef):
                    self.classes.append({'name': node.name, 'file': filepath, 'lineno': node.lineno})
                    current_class = node.name
                    current_function = None # Reset current function when a class is found
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        callee_name = node.func.id
                        if current_function:
                            self.dependencies[current_function].append(callee_name)
                        elif current_class:
                            # For now, just track calls within class methods, not class instantiation
                            # This part needs more sophisticated handling for methods vs. functions
                            pass
                    elif isinstance(node.func, ast.Attribute):
                        # Handle method calls like obj.method()
                        if isinstance(node.func.value, ast.Name):
                            callee_name = node.func.attr
                            if current_function:
                                self.dependencies[current_function].append(callee_name)
                            elif current_class:
                                pass

        except SyntaxError as e:
            print(f"Syntax error in {filepath}: {e}")
        except Exception as e:
            print(f"Error processing {filepath}: {e}")

    def analyze_project(self):
        for root, _, files in os.walk(self.project_path):
            for file in files:
                if file.endswith('.py'):  # Focusing on Python files for now
                    filepath = os.path.join(root, file)
                    self.analyze_file(filepath)

    def identify_workflows(self):
        # Simple heuristic: functions that are not called by any other function
        # within the analyzed scope might be entry points or standalone workflows.
        # Also, functions that call multiple other functions could be orchestrators.
        all_functions = {f['name'] for f in self.functions}
        called_functions = set()
        for caller, callees in self.dependencies.items():
            for callee in callees:
                called_functions.add(callee)

        entry_points = all_functions - called_functions
        potential_workflows = []

        for func_name in entry_points:
            potential_workflows.append({'type': 'entry_point', 'name': func_name, 'description': f'Potential entry point or standalone task: {func_name}'})

        for func_name, callees in self.dependencies.items():
            if len(callees) > 1:
                potential_workflows.append({'type': 'orchestrator', 'name': func_name, 'description': f'Potential orchestrator calling multiple functions: {func_name}'})
        
        return potential_workflows

    def get_analysis_results(self):
        return {
            'modules': self.modules,
            'functions': self.functions,
            'classes': self.classes,
            'dependencies': {k: list(set(v)) for k, v in self.dependencies.items()},
            'workflows': self.identify_workflows()
        }

if __name__ == '__main__':
    dummy_project_path = "/home/ubuntu/code_analysis_framework/dummy_project"
    os.makedirs(dummy_project_path, exist_ok=True)
    with open(os.path.join(dummy_project_path, "main.py"), "w") as f:
        f.write("""def func_a():
    print("Function A")
    func_b()

def func_b():
    print("Function B")

class MyClass:
    def __init__(self):
        pass

    def method_x(self):
        print("Method X")
        self.method_y()

    def method_y(self):
        print("Method Y")
        func_a()
""")
    with open(os.path.join(dummy_project_path, "utils.py"), "w") as f:
        f.write("""def utility_function():
    return 123
""")

    analyzer = CodeAnalyzer(dummy_project_path)
    analyzer.analyze_project()
    results = analyzer.get_analysis_results()
    print(results)

    import shutil
    shutil.rmtree(dummy_project_path)


