## To-Do List

### Phase 1: Anforderungsanalyse und Framework-Design
- [x] Detaillierte Anforderungen klären
- [x] Architektur des Frameworks entwerfen
- [x] Technologiestack festlegen

### Phase 2: Codebase-Analyse-Engine entwickeln
- [x] Code-Parsing und AST-Analyse implementieren
- [x] Funktions- und Klassenextraktion entwickeln
- [x] Abhängigkeitsanalyse implementieren
- [x] Potenzielle Workflows identifizieren

### Phase 3: Automatische Button- und Workflow-Generierung
- [x] Generierung von UI-Komponenten (Buttons) implementieren
- [x] Workflow-Definitionen erstellen (z.B. YAML, JSON)
- [x] Code-Injektion für Button-Handler entwickeln

### Phase 4: Benutzer-Lokalisierung und File-Detection
- [x] Algorithmen zur Erkennung von Benutzerdateien implementieren
- [x] Dateipfad-Mapping und -Verwaltung entwickeln

### Phase 5: Integration und Testing
- [x] Alle Komponenten integrieren
- [x] Unit-Tests und Integrationstests durchführen
- [ ] End-to-End-Tests in einer Beispiel-Codebase

### Phase 6: Demonstration und Dokumentation
- [ ] Eine Beispiel-Codebase vorbereiten
- [ ] Framework-Nutzung demonstrieren
- [ ] Technische Dokumentation erstellen
- [ ] Benutzerhandbuch verfassen

