import ast
import os

class CodeInjector:
    def __init__(self, project_path):
        self.project_path = project_path

    def inject_button_handlers(self, workflow_config, target_file=None):
        """
        Inject button handler code into the target file or create a new handler file.
        """
        if target_file is None:
            target_file = os.path.join(self.project_path, 'auto_generated_handlers.py')

        handler_code = self._generate_handler_code(workflow_config)
        
        with open(target_file, 'w') as f:
            f.write(handler_code)
        
        return target_file

    def _generate_handler_code(self, workflow_config):
        """
        Generate Python code for button handlers based on workflow configuration.
        """
        code = """# Auto-generated button handlers
import sys
import os

# Add the project path to sys.path to import project modules
project_path = os.path.dirname(os.path.abspath(__file__))
if project_path not in sys.path:
    sys.path.append(project_path)

class ButtonHandlers:
    def __init__(self):
        self.handlers = {}
        self._register_handlers()

    def _register_handlers(self):
        \"\"\"Register all button handlers\"\"\"
"""

        # Generate handler methods for each button
        for button in workflow_config.get('buttons', []):
            action = button['action']
            code += f"""
        self.handlers['{action}'] = self.handle_{action}
"""

        code += """
    def execute_action(self, action_name, *args, **kwargs):
        \"\"\"Execute a button action by name\"\"\"
        if action_name in self.handlers:
            try:
                return self.handlers[action_name](*args, **kwargs)
            except Exception as e:
                return {'error': str(e), 'action': action_name}
        else:
            return {'error': f'Unknown action: {action_name}', 'action': action_name}
"""

        # Generate individual handler methods
        for button in workflow_config.get('buttons', []):
            action = button['action']
            description = button.get('description', '')
            code += f"""
    def handle_{action}(self, *args, **kwargs):
        \"\"\"Handler for {action}: {description}\"\"\"
        try:
            # Try to import and execute the original function
            # This is a simplified approach - in practice, you'd need more sophisticated
            # module discovery and function execution
            
            # For demonstration, we'll just return a success message
            # In a real implementation, this would dynamically import and call the function
            result = f"Executed {action} successfully"
            
            # TODO: Add actual function execution logic here
            # Example:
            # from your_module import {action}
            # result = {action}(*args, **kwargs)
            
            return {{'success': True, 'result': result, 'action': '{action}'}}
        except Exception as e:
            return {{'error': str(e), 'action': '{action}'}}
"""

        code += """

# Global handler instance
button_handlers = ButtonHandlers()

def execute_button_action(action_name, *args, **kwargs):
    \"\"\"Global function to execute button actions\"\"\"
    return button_handlers.execute_action(action_name, *args, **kwargs)

if __name__ == '__main__':
    # Test the handlers
    import json
    
    print("Available handlers:")
    for action in button_handlers.handlers.keys():
        print(f"  - {action}")
    
    # Test execution
    if len(sys.argv) > 1:
        action = sys.argv[1]
        result = execute_button_action(action)
        print(json.dumps(result, indent=2))
"""

        return code

    def create_flask_api(self, workflow_config, output_file=None):
        """
        Create a Flask API to serve the button handlers via HTTP.
        """
        if output_file is None:
            output_file = os.path.join(self.project_path, 'api_server.py')

        flask_code = """# Auto-generated Flask API for button handlers
from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os

# Add the project path to sys.path
project_path = os.path.dirname(os.path.abspath(__file__))
if project_path not in sys.path:
    sys.path.append(project_path)

from auto_generated_handlers import execute_button_action

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/actions', methods=['GET'])
def get_available_actions():
    \"\"\"Get list of available actions\"\"\"
    from auto_generated_handlers import button_handlers
    actions = list(button_handlers.handlers.keys())
    return jsonify({'actions': actions})

@app.route('/api/execute/<action_name>', methods=['POST'])
def execute_action(action_name):
    \"\"\"Execute a specific action\"\"\"
    try:
        data = request.get_json() or {}
        args = data.get('args', [])
        kwargs = data.get('kwargs', {})
        
        result = execute_button_action(action_name, *args, **kwargs)
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e), 'action': action_name}), 500

@app.route('/api/workflow-config', methods=['GET'])
def get_workflow_config():
    \"\"\"Get the workflow configuration\"\"\"
    try:
        import json
        with open('workflow_config.json', 'r') as f:
            config = json.load(f)
        return jsonify(config)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def index():
    \"\"\"Serve the main interface\"\"\"
    try:
        with open('test_interface.html', 'r') as f:
            return f.read()
    except FileNotFoundError:
        return "Interface not found. Please generate the HTML interface first.", 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
"""

        with open(output_file, 'w') as f:
            f.write(flask_code)
        
        return output_file

if __name__ == '__main__':
    # Test with dummy workflow config
    dummy_config = {
        'buttons': [
            {'action': 'func_a', 'label': 'Function A', 'type': 'entry_point'},
            {'action': 'func_b', 'label': 'Function B', 'type': 'orchestrator'}
        ]
    }
    
    injector = CodeInjector('/home/ubuntu/code_analysis_framework')
    handler_file = injector.inject_button_handlers(dummy_config)
    api_file = injector.create_flask_api(dummy_config)
    
    print(f"Generated handler file: {handler_file}")
    print(f"Generated API file: {api_file}")

