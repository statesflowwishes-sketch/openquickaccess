# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

## Modellinformationen

*   **Name des Modells:** Trilium
*   **Typ:** Docker-App
*   **Kurzbeschreibung:** Trilium Notes ist eine kostenlose, quelloffene, hierarchische Notiz-Anwendung mit Fokus auf den Aufbau großer persönlicher Wissensdatenbanken.
*   **Offizielle Website/GitHub-Repo:** https://github.com/zadam/trilium

## 1. Kernfunktionen (Core Features)

*   **Container-Management:** Ja (primär über Docker und Docker Compose bereitgestellt)
    *   Erstellung, Start, Stopp, Löschen: Ja (über Docker)
    *   Docker Compose Integration: Ja (häufig in Docker Compose Setups verwendet)
*   **Image-Management:** Ja (Docker-Images sind verfügbar und werden verwaltet)
    *   Verwaltung (Pull, Push, Build, Tagging): Ja (über Docker)
    *   Private Registry Support: Ja (über Docker)
*   **Netzwerk-Management:** Ja (konfigurierbar über Docker-Netzwerke)
    *   Konfiguration (Bridge, Host, Overlay): Ja (über Docker)
    *   DNS-Auflösung: Ja (über Docker)
*   **Volume-Management:** Ja
    *   Persistente Speicherung: Ja (empfohlen über Docker Volumes für Daten und Datenbank)
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): Ja (unterstützt)
*   **Orchestrierung:** Teilweise (keine integrierte Orchestrierung, aber gut mit Docker Swarm integrierbar)
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): Ja (Integration)
*   **Sicherheit:** Ja (bietet TLS-Konfiguration)
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): Ja (abhängig von der Docker-Host-Konfiguration)
*   **Monitoring & Logging:** Ja (Logs sind über Docker verfügbar, Integration mit Monitoring-Tools möglich)
    *   Tools für Performance/Log-Aggregation: Ja (Integration mit externen Tools)

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** Ja (Trilium kann direkt TLS konfigurieren, oder über Reverse Proxy)
*   **Automatisierung (z.B. Let's Encrypt):** Ja (in Kombination mit Reverse Proxies und Let's Encrypt)
*   **Wildcard-Zertifikate:** Ja (abhängig vom Reverse Proxy Setup)
*   **Zentrales Zertifikatsmanagement:** Teilweise (über Reverse Proxy oder externe Tools)

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** Ja (für persönliche Wissensdatenbanken)
*   **Kleine Unternehmen/Startups:** Teilweise (für interne Dokumentation, Wissensmanagement)
*   **Entwickler:** Ja (Open-Source, Skripting-Möglichkeiten, Code-Notizen)
*   **Bildungseinrichtungen:** Teilweise (für Notizen und Lernmaterialien)

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** Ja (lokale Benutzer)
*   **Autorisierungsmodelle (z.B. RBAC):** Teilweise (grundlegende Benutzerverwaltung)
*   **Benutzerverwaltung:** Ja (integrierte Benutzerverwaltung)
*   **Integration mit bestehenden Identitätssystemen:** Nein (keine direkte Integration)

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** Ja (Notizen werden in einer SQLite-Datenbank gespeichert)
*   **Performance (I/O, Latenz):** Hoch (abhängig von der zugrunde liegenden Speicherlösung)
*   **Snapshot-Fähigkeiten:** Ja (abhängig vom zugrunde liegenden Dateisystem/Speicherlösung oder Datenbank-Snapshots)
*   **Backup & Restore:** Ja (Datenbank-Backups und Export/Import-Funktionen für Notizen)
*   **Skalierbarkeit:** Ja (kann große Mengen an Notizen verwalten)

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** Ja (AGPLv3 Lizenz)
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** Ja (Synchronisation mit einem Trilium-Server, Notizen-Versionierung)
*   **Integration (Anbindung an andere Dienste):** Teilweise (Fokus auf Notizen, Integrationen über Skripte möglich)
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** Ja (Zugriffskontrolle, Daten werden auf dem Host gespeichert)
*   **Skalierbarkeit:** Ja (kann große Mengen an Notizen verwalten)

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** Ja (volle Kontrolle über den Speicherort der Notizen, besonders mit selbstgehostetem Server)
*   **Anbieterunabhängigkeit:** Ja (durch Open-Source und selbstgehostete Natur)
*   **Transparenz (Quellcode, Funktionsweise):** Ja (vollständig transparent)
*   **Rechtliche Konformität (z.B. DSGVO):** Ja (durch Selbsthosting)
*   **Föderation:** Nein (keine Föderationsfunktionen)

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** SQLite (intern verwendet)
*   **Einfache Bereitstellung:** Ja (Datenbank ist in der Anwendung integriert)
*   **Management-Tools:** Nein (keine integrierten, aber SQLite-Tools können verwendet werden)
*   **Backup & Recovery:** Ja (Datenbank-Backups sind Teil der Gesamt-Backup-Strategie)
*   **Performance:** Hoch (für persönliche Wissensdatenbanken)

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** Ja (Trilium kann in Rootless Docker-Umgebungen ausgeführt werden)
*   **Serverless-Funktionen:** Nein (keine native Serverless-Plattform)
*   **Ressourcenverbrauch (Leerlauf):** Gering (für die Kernanwendung)
*   **Sicherheit (reduzierte Privilegien):** Ja (durch Rootless-Ausführung erhöht)

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** Ja (gut dokumentiert für Docker Rootless)
*   **Kompatibilität (Docker-Images/Funktionen):** Ja (volle Kompatibilität mit den meisten Docker-Funktionen)
*   **Performance-Auswirkungen:** Gering (kaum spürbare Performance-Einbußen)
*   **Sicherheitsvorteile:** Ja (erhöhte Sicherheit durch Ausführung als Nicht-Root-Benutzer, Isolation von Host-Systemressourcen)


