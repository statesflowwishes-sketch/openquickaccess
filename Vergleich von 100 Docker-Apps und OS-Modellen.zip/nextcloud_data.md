# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

## Modellinformationen

*   **Name des Modells:** Nextcloud
*   **Typ:** Docker-App
*   **Kurzbeschreibung:** Nextcloud ist eine selbstgehostete Open-Source-Plattform für Dateisynchronisation, -freigabe und -kollaboration, die eine sichere Alternative zu Cloud-Diensten bietet.
*   **Offizielle Website/GitHub-Repo:** https://nextcloud.com/

## 1. Kernfunktionen (Core Features)

*   **Container-Management:** Teilweise (als Docker-Image verfügbar, Management über Docker-Tools)
    *   Erstellung, Start, Stopp, Löschen: Ja (über Docker)
    *   Docker Compose Integration: Ja (häufig in Docker Compose Setups verwendet)
*   **Image-Management:** Ja (Docker-Images sind verfügbar und werden verwaltet)
    *   Verwaltung (Pull, Push, Build, Tagging): Ja (über Docker)
    *   Private Registry Support: Ja (über Docker)
*   **Netzwerk-Management:** Ja (konfigurierbar über Docker-Netzwerke)
    *   Konfiguration (Bridge, Host, Overlay): Ja (über Docker)
    *   DNS-Auflösung: Ja (über Docker)
*   **Volume-Management:** Ja
    *   Persistente Speicherung: Ja (empfohlen über Docker Volumes)
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): Ja (unterstützt)
*   **Orchestrierung:** Teilweise (keine integrierte Orchestrierung, aber gut mit Kubernetes und Docker Swarm integrierbar)
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): Ja (Integration)
*   **Sicherheit:** Ja (bietet verschiedene Sicherheitsfunktionen wie End-to-End-Verschlüsselung, 2FA)
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): Ja (abhängig von der Docker-Host-Konfiguration)
*   **Monitoring & Logging:** Ja (Logs sind über Docker verfügbar, Integration mit Monitoring-Tools möglich)
    *   Tools für Performance/Log-Aggregation: Ja (Integration mit externen Tools)

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** Ja (einfache Integration und Verwaltung von TLS/SSL-Zertifikaten)
*   **Automatisierung (z.B. Let's Encrypt):** Ja (oft in Kombination mit Reverse Proxies wie Nginx/Caddy und Let's Encrypt)
*   **Wildcard-Zertifikate:** Ja (abhängig vom Reverse Proxy Setup)
*   **Zentrales Zertifikatsmanagement:** Teilweise (über Reverse Proxy oder AIO-Installation)

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** Ja (einfache Installation, Community-Support, Fokus auf Privatsphäre)
*   **Kleine Unternehmen/Startups:** Ja (Skalierbarkeit, Kollaborationsfunktionen, Kosteneffizienz)
*   **Entwickler:** Ja (flexible Bereitstellung, API-Zugriff)
*   **Bildungseinrichtungen:** Ja (Kollaborations- und Speicherlösung)

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** Ja (Lokal, LDAP/AD, OAuth2, SAML/SSO)
*   **Autorisierungsmodelle (z.B. RBAC):** Ja (Rollenbasierte Zugriffskontrolle, feingranulare Berechtigungen)
*   **Benutzerverwaltung:** Ja (umfassende Benutzer- und Gruppenverwaltung)
*   **Integration mit bestehenden Identitätssystemen:** Ja (LDAP/AD, Shibboleth, SAML)

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** Ja (effiziente Nutzung und Zuweisung von Speicherplatz)
*   **Performance (I/O, Latenz):** Hoch (abhängig von der zugrunde liegenden Speicherlösung)
*   **Snapshot-Fähigkeiten:** Ja (abhängig vom zugrunde liegenden Dateisystem/Speicherlösung)
*   **Backup & Restore:** Ja (umfassende Backup- und Restore-Optionen)
*   **Skalierbarkeit:** Ja (einfache Erweiterung des Speicherplatzes und der Performance)

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** Ja (AGPLv3 Lizenz)
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** Ja (umfassend, inkl. Office-Integration, Talk, Kalender, Kontakte)
*   **Integration (Anbindung an andere Dienste):** Ja (umfangreiche App-Store-Integration, APIs)
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** Ja (End-to-End-Verschlüsselung, serverseitige Verschlüsselung, 2FA, Brute-Force-Schutz)
*   **Skalierbarkeit:** Ja (horizontal skalierbar)

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** Ja (volle Kontrolle über den Speicherort und den Zugriff auf Daten)
*   **Anbieterunabhängigkeit:** Ja (durch Open-Source und selbstgehostete Natur)
*   **Transparenz (Quellcode, Funktionsweise):** Ja (vollständig transparent)
*   **Rechtliche Konformität (z.B. DSGVO):** Ja (bietet Funktionen zur Einhaltung von Datenschutzbestimmungen)
*   **Föderation:** Ja (Federated Cloud Sharing)

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** MySQL/MariaDB, PostgreSQL, SQLite (nur für Testzwecke)
*   **Einfache Bereitstellung:** Ja (gut dokumentierte Setups mit Docker Compose)
*   **Management-Tools:** Nein (keine integrierten, aber kompatibel mit externen Tools)
*   **Backup & Recovery:** Ja (Datenbank-Backups sind Teil der Gesamt-Backup-Strategie)
*   **Performance:** Hoch (abhängig von der gewählten Datenbank und Hardware)

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** Ja (Nextcloud kann in Rootless Docker-Umgebungen ausgeführt werden)
*   **Serverless-Funktionen:** Nein (keine native Serverless-Plattform, kann aber in Serverless-Umgebungen wie OpenFaaS integriert werden)
*   **Ressourcenverbrauch (Leerlauf):** Mittel (abhängig von der Anzahl der aktivierten Apps und Benutzer)
*   **Sicherheit (reduzierte Privilegien):** Ja (durch Rootless-Ausführung erhöht)

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** Ja (gut dokumentiert für Docker Rootless)
*   **Kompatibilität (Docker-Images/Funktionen):** Ja (volle Kompatibilität mit den meisten Docker-Funktionen)
*   **Performance-Auswirkungen:** Gering (kaum spürbare Performance-Einbußen)
*   **Sicherheitsvorteile:** Ja (erhöhte Sicherheit durch Ausführung als Nicht-Root-Benutzer, Isolation von Host-Systemressourcen)


