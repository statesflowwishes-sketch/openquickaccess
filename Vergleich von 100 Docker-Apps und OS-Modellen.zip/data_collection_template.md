# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

Diese Vorlage dient zur systematischen Erfassung von Informationen für jedes der 100 ausgewählten Docker-App- und OS/ISO-Modelle, basierend auf den zuvor definierten Vergleichsdimensionen.

## Modellinformationen

*   **Name des Modells:** [Name des Modells]
*   **Typ:** [Docker-App / OS / ISO]
*   **Kurzbeschreibung:** [Ein kurzer Überblick über das Modell]
*   **Offizielle Website/GitHub-Repo:** [URL]

## 1. Kernfunktionen (Core Features)

*   **Container-Management:**
    *   Erstellung, Start, Stopp, Löschen: [Ja/Nein/Teilweise]
    *   Docker Compose Integration: [Ja/Nein/Teilweise]
*   **Image-Management:**
    *   Verwaltung (Pull, Push, Build, Tagging): [Ja/Nein/Teilweise]
    *   Private Registry Support: [Ja/Nein/Teilweise]
*   **Netzwerk-Management:**
    *   Konfiguration (Bridge, Host, Overlay): [Ja/Nein/Teilweise]
    *   DNS-Auflösung: [Ja/Nein/Teilweise]
*   **Volume-Management:**
    *   Persistente Speicherung: [Ja/Nein/Teilweise]
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): [Ja/Nein/Teilweise]
*   **Orchestrierung:**
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): [Ja/Nein/Teilweise/N/A]
*   **Sicherheit:**
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): [Ja/Nein/Teilweise]
*   **Monitoring & Logging:**
    *   Tools für Performance/Log-Aggregation: [Ja/Nein/Teilweise]

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** [Ja/Nein/Teilweise]
*   **Automatisierung (z.B. Let's Encrypt):** [Ja/Nein/Teilweise]
*   **Wildcard-Zertifikate:** [Ja/Nein/Teilweise]
*   **Zentrales Zertifikatsmanagement:** [Ja/Nein/Teilweise]

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** [Ja/Nein]
*   **Kleine Unternehmen/Startups:** [Ja/Nein]
*   **Entwickler:** [Ja/Nein]
*   **Bildungseinrichtungen:** [Ja/Nein]

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** [Liste der unterstützten Methoden]
*   **Autorisierungsmodelle (z.B. RBAC):** [Ja/Nein/Beschreibung]
*   **Benutzerverwaltung:** [Ja/Nein/Beschreibung]
*   **Integration mit bestehenden Identitätssystemen:** [Ja/Nein/Beschreibung]

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** [Ja/Nein/Beschreibung]
*   **Performance (I/O, Latenz):** [Hoch/Mittel/Niedrig/Beschreibung]
*   **Snapshot-Fähigkeiten:** [Ja/Nein/Teilweise]
*   **Backup & Restore:** [Ja/Nein/Teilweise]
*   **Skalierbarkeit:** [Ja/Nein/Beschreibung]

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** [Ja/Nein/Link zur Lizenz]
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** [Ja/Nein/Teilweise/Beschreibung]
*   **Integration (Anbindung an andere Dienste):** [Ja/Nein/Beschreibung]
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** [Ja/Nein/Beschreibung]
*   **Skalierbarkeit:** [Ja/Nein/Beschreibung]

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** [Ja/Nein/Beschreibung]
*   **Anbieterunabhängigkeit:** [Ja/Nein/Beschreibung]
*   **Transparenz (Quellcode, Funktionsweise):** [Ja/Nein/Beschreibung]
*   **Rechtliche Konformität (z.B. DSGVO):** [Ja/Nein/Beschreibung]
*   **Föderation:** [Ja/Nein/Beschreibung]

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** [Liste der unterstützten Typen]
*   **Einfache Bereitstellung:** [Ja/Nein/Beschreibung]
*   **Management-Tools:** [Ja/Nein/Beschreibung]
*   **Backup & Recovery:** [Ja/Nein/Beschreibung]
*   **Performance:** [Hoch/Mittel/Niedrig/Beschreibung]

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** [Ja/Nein/Teilweise]
*   **Serverless-Funktionen:** [Ja/Nein/Teilweise]
*   **Ressourcenverbrauch (Leerlauf):** [Gering/Mittel/Hoch]
*   **Sicherheit (reduzierte Privilegien):** [Ja/Nein/Beschreibung]

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** [Ja/Nein/Beschreibung]
*   **Kompatibilität (Docker-Images/Funktionen):** [Ja/Nein/Teilweise]
*   **Performance-Auswirkungen:** [Gering/Mittel/Hoch]
*   **Sicherheitsvorteile:** [Ja/Nein/Beschreibung]

