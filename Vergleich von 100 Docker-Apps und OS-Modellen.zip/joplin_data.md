
# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

## Modellinformationen

*   **Name des Modells:** Joplin
*   **Typ:** Docker-App
*   **Kurzbeschreibung:** Joplin ist eine kostenlose, quelloffene Notiz- und Aufgabenverwaltungsanwendung, die eine große Anzahl von Notizen in Notizbüchern organisieren kann und Synchronisation über verschiedene Cloud-Dienste oder einen eigenen Server ermöglicht.
*   **Offizielle Website/GitHub-Repo:** https://joplinapp.org/

## 1. Kernfunktionen (Core Features)

*   **Container-Management:** Teilweise (Joplin Server ist als Docker-Image verfügbar, Management über Docker-Tools)
    *   Erstellung, Start, Stopp, Löschen: Ja (über Docker)
    *   Docker Compose Integration: Ja (häufig in Docker Compose Setups verwendet)
*   **Image-Management:** Ja (Docker-Images sind verfügbar und werden verwaltet)
    *   Verwaltung (Pull, Push, Build, Tagging): Ja (über Docker)
    *   Private Registry Support: Ja (über Docker)
*   **Netzwerk-Management:** Ja (konfigurierbar über Docker-Netzwerke)
    *   Konfiguration (Bridge, Host, Overlay): Ja (über Docker)
    *   DNS-Auflösung: Ja (über Docker)
*   **Volume-Management:** Ja
    *   Persistente Speicherung: Ja (empfohlen über Docker Volumes für Joplin Server)
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): Ja (unterstützt)
*   **Orchestrierung:** Teilweise (keine integrierte Orchestrierung, aber gut mit Kubernetes und Docker Swarm integrierbar)
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): Ja (Integration)
*   **Sicherheit:** Ja (bietet End-to-End-Verschlüsselung für Notizen)
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): Ja (abhängig von der Docker-Host-Konfiguration)
*   **Monitoring & Logging:** Ja (Logs sind über Docker verfügbar, Integration mit Monitoring-Tools möglich)
    *   Tools für Performance/Log-Aggregation: Ja (Integration mit externen Tools)

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** Ja (Joplin Server unterstützt SSL/TLS; Client-Zertifikate können konfiguriert werden)
*   **Automatisierung (z.B. Let's Encrypt):** Ja (oft in Kombination mit Reverse Proxies wie Nginx/Caddy und Let's Encrypt)
*   **Wildcard-Zertifikate:** Ja (abhängig vom Reverse Proxy Setup)
*   **Zentrales Zertifikatsmanagement:** Teilweise (über Reverse Proxy oder externe Tools)

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** Ja (einfache Installation des Servers, Fokus auf Privatsphäre und Kontrolle)
*   **Kleine Unternehmen/Startups:** Ja (für interne Notizverwaltung und Kollaboration)
*   **Entwickler:** Ja (Markdown-Unterstützung, API, Skripting-Möglichkeiten)
*   **Bildungseinrichtungen:** Ja (für Notizen und Lernmaterialien)

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** Ja (lokale Benutzer, SSO-Unterstützung für Joplin Server in Diskussion/Entwicklung)
*   **Autorisierungsmodelle (z.B. RBAC):** Teilweise (grundlegende Benutzerverwaltung, keine ausgeprägte RBAC)
*   **Benutzerverwaltung:** Ja (Joplin Server bietet Benutzerverwaltung)
*   **Integration mit bestehenden Identitätssystemen:** Teilweise (SSO-Integration ist ein gewünschtes Feature)

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** Ja (Notizen werden in einer Datenbank oder Dateisystem gespeichert)
*   **Performance (I/O, Latenz):** Hoch (abhängig von der zugrunde liegenden Speicherlösung und Datenbank)
*   **Snapshot-Fähigkeiten:** Ja (abhängig vom zugrunde liegenden Dateisystem/Speicherlösung oder Datenbank-Snapshots)
*   **Backup & Restore:** Ja (Datenbank-Backups und Export/Import-Funktionen für Notizen)
*   **Skalierbarkeit:** Ja (Joplin Server kann skaliert werden, um mehr Benutzer und Notizen zu verwalten)

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** Ja (MIT-Lizenz)
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** Ja (Synchronisation mit verschiedenen Cloud-Diensten wie Nextcloud, Dropbox, OneDrive, WebDAV; Notizen-Versionierung)
*   **Integration (Anbindung an andere Dienste):** Ja (umfangreiche Synchronisationsoptionen)
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** Ja (End-to-End-Verschlüsselung für Notizen)
*   **Skalierbarkeit:** Ja (Joplin Server ist skalierbar)

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** Ja (volle Kontrolle über den Speicherort der Notizen, besonders mit selbstgehostetem Server)
*   **Anbieterunabhängigkeit:** Ja (durch Open-Source und vielfältige Synchronisationsoptionen)
*   **Transparenz (Quellcode, Funktionsweise):** Ja (vollständig transparent)
*   **Rechtliche Konformität (z.B. DSGVO):** Ja (durch Selbsthosting und E2E-Verschlüsselung)
*   **Föderation:** Nein (keine Föderationsfunktionen)

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** SQLite (Standard für Clients), PostgreSQL (für Joplin Server)
*   **Einfache Bereitstellung:** Ja (Joplin Server mit Docker Compose)
*   **Management-Tools:** Nein (keine integrierten, aber kompatibel mit externen Tools)
*   **Backup & Recovery:** Ja (Datenbank-Backups sind Teil der Gesamt-Backup-Strategie)
*   **Performance:** Hoch (abhängig von der gewählten Datenbank und Hardware)

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** Ja (Joplin Server kann in Rootless Podman/Docker-Umgebungen ausgeführt werden)
*   **Serverless-Funktionen:** Nein (keine native Serverless-Plattform, aber es gibt serverless-Funktionen für Joplin-Plugins)
*   **Ressourcenverbrauch (Leerlauf):** Gering (für Joplin Server)
*   **Sicherheit (reduzierte Privilegien):** Ja (durch Rootless-Ausführung erhöht)

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** Ja (gut dokumentiert für Podman/Docker Rootless)
*   **Kompatibilität (Docker-Images/Funktionen):** Ja (volle Kompatibilität mit den meisten Docker-Funktionen)
*   **Performance-Auswirkungen:** Gering (kaum spürbare Performance-Einbußen)
*   **Sicherheitsvorteile:** Ja (erhöhte Sicherheit durch Ausführung als Nicht-Root-Benutzer, Isolation von Host-Systemressourcen)


