# Vergleichsdimensionen für Docker-Apps und OS/ISO-Modelle

Dies sind die Dimensionen, anhand derer die 100 Verbrauchermodelle von Docker-Apps und OS/ISO verglichen werden. Jede Dimension wird mit spezifischen Kriterien unterlegt, um eine konsistente und messbare Bewertung zu gewährleisten.

## 1. Kernfunktionen (Core Features)

**Kriterien:**
*   **Container-Management:** Unterstützung für Erstellung, Start, Stopp, Löschen von Containern. Integration mit Docker Compose. 
*   **Image-Management:** Verwaltung von Docker-Images (Pull, Push, Build, Tagging). Unterstützung für private Registries.
*   **Netzwerk-Management:** Konfiguration von Containernetzwerken (Bridge, Host, Overlay). DNS-Auflösung innerhalb von Containern.
*   **Volume-Management:** Persistente Speicherung von Containerdaten. Unterstützung für verschiedene Speichertreiber (z.B. Bind Mounts, Named Volumes).
*   **Orchestrierung:** Integrierte oder unterstützte Orchestrierungstools (z.B. Docker Swarm, Kubernetes-Integration).
*   **Sicherheit:** Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp-Profile, AppArmor-Profile).
*   **Monitoring & Logging:** Verfügbarkeit von Tools zur Überwachung der Container-Performance und zur Aggregation von Logs.

## 2. Netzwerkzertifikate (Network Certificates)

**Kriterien:**
*   **TLS/SSL-Unterstützung:** Einfache Integration und Verwaltung von TLS/SSL-Zertifikaten für sichere Kommunikation.
*   **Automatisierung:** Unterstützung für automatische Zertifikatserneuerung (z.B. Let's Encrypt-Integration).
*   **Wildcard-Zertifikate:** Unterstützung für Wildcard-Zertifikate.
*   **Zentrales Zertifikatsmanagement:** Möglichkeit zur zentralen Verwaltung von Zertifikaten für mehrere Dienste.

## 3. Zielgruppensegmente (Target Audience Segments)

**Kriterien:**
*   **Heimnutzer/Hobbyisten:** Einfache Installation und Konfiguration, geringe Hardwareanforderungen, Community-Support.
*   **Kleine Unternehmen/Startups:** Skalierbarkeit, einfache Bereitstellung, grundlegende Management-Tools, Kosteneffizienz.
*   **Entwickler:** Schnelle Iteration, einfache Integration in Entwicklungsumgebungen, Debugging-Tools.
*   **Bildungseinrichtungen:** Leichte Lernkurve, Ressourcen für den Unterricht, kostengünstige Lizenzen.

## 4. Self Hosting Identity

**Kriterien:**
*   **Authentifizierungsmethoden:** Unterstützung für lokale Benutzer, LDAP, OAuth, Single Sign-On (SSO).
*   **Autorisierungsmodelle:** Rollenbasierte Zugriffskontrolle (RBAC), feingranulare Berechtigungen.
*   **Benutzerverwaltung:** Einfache Erstellung, Bearbeitung und Löschung von Benutzern und Gruppen.
*   **Integration mit bestehenden Identitätssystemen:** Kompatibilität mit gängigen Identity Providern.

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

**Kriterien:**
*   **Speicherplatzverwaltung:** Effiziente Nutzung und Zuweisung von virtuellem Speicherplatz.
*   **Performance:** I/O-Leistung, Latenzzeiten bei Zugriffen auf virtuelle Festplatten.
*   **Snapshot-Fähigkeiten:** Unterstützung für Snapshots und Rollbacks von virtuellen Festplatten.
*   **Backup & Restore:** Mechanismen für die Sicherung und Wiederherstellung von Daten auf virtuellen Festplatten.
*   **Skalierbarkeit:** Möglichkeit zur einfachen Erweiterung des Speicherplatzes.

## 6. Self Cloud Offensafen (Self-Cloud Open Safes - likely referring to open-source cloud storage/platforms)

**Kriterien:**
*   **Open-Source-Status:** Vollständig quelloffen und transparent.
*   **Funktionsumfang:** Dateisynchronisation, Freigabe, Kollaboration, Versionierung.
*   **Integration:** Anbindung an andere Dienste und Anwendungen.
*   **Sicherheit:** Verschlüsselung (End-to-End, Ruhezustand), Zugriffskontrolle.
*   **Skalierbarkeit:** Fähigkeit, große Datenmengen und viele Benutzer zu verwalten.

## 7. Digitale Souveränität (Digital Sovereignty)

**Kriterien:**
*   **Datenhoheit:** Kontrolle über den Speicherort und den Zugriff auf Daten.
*   **Anbieterunabhängigkeit:** Vermeidung von Vendor Lock-in durch offene Standards und Formate.
*   **Transparenz:** Offenlegung des Quellcodes und der Funktionsweise.
*   **Rechtliche Konformität:** Einhaltung relevanter Datenschutzgesetze (z.B. DSGVO).
*   **Föderation:** Möglichkeit zur Vernetzung mit anderen unabhängigen Instanzen.

## 8. Database und Databanken (Database and Databases)

**Kriterien:**
*   **Unterstützte Datenbanktypen:** Kompatibilität mit relationalen (z.B. PostgreSQL, MySQL) und NoSQL-Datenbanken (z.B. MongoDB, Redis).
*   **Einfache Bereitstellung:** Leichtigkeit der Installation und Konfiguration von Datenbanken in der Umgebung.
*   **Management-Tools:** Verfügbarkeit von Tools zur Datenbankverwaltung (z.B. phpMyAdmin, pgAdmin).
*   **Backup & Recovery:** Mechanismen für die Sicherung und Wiederherstellung von Datenbanken.
*   **Performance:** Leistung der Datenbankzugriffe in der jeweiligen Umgebung.

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless - likely referring to containerization without root privileges or serverless functions)

**Kriterien:**
*   **Rootless-Container-Unterstützung:** Fähigkeit, Container ohne Root-Rechte auszuführen.
*   **Serverless-Funktionen:** Unterstützung für die Bereitstellung und Ausführung von Serverless-Funktionen.
*   **Ressourcenverbrauch:** Geringer Ressourcenverbrauch im Leerlauf.
*   **Sicherheit:** Erhöhte Sicherheit durch reduzierte Privilegien.

## 10. RootLess (Rootless - specific focus on rootless container execution)

**Kriterien:**
*   **Einfache Konfiguration:** Leichtigkeit der Einrichtung von Rootless-Containern.
*   **Kompatibilität:** Unterstützung für gängige Docker-Images und -Funktionen im Rootless-Modus.
*   **Performance-Auswirkungen:** Geringe oder keine Performance-Einbußen im Rootless-Modus.
*   **Sicherheitsvorteile:** Detaillierte Beschreibung der Sicherheitsvorteile durch Rootless-Ausführung.

