# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

## Modellinformationen

*   **Name des Modells:** Bookstack
*   **Typ:** Docker-App
*   **Kurzbeschreibung:** BookStack ist eine einfache, quelloffene, selbstgehostete Plattform zur Organisation und Speicherung von Informationen, ideal für Dokumentationen und Wissensmanagement.
*   **Offizielle Website/GitHub-Repo:** https://www.bookstackapp.com/ / https://github.com/BookStackApp/BookStack

## 1. Kernfunktionen (Core Features)

*   **Container-Management:** Ja (primär über Docker und Docker Compose bereitgestellt)
    *   Erstellung, Start, Stopp, Löschen: Ja (über Docker)
    *   Docker Compose Integration: Ja (häufig in Docker Compose Setups verwendet)
*   **Image-Management:** Ja (Docker-Images sind verfügbar und werden verwaltet)
    *   Verwaltung (Pull, Push, Build, Tagging): Ja (über Docker)
    *   Private Registry Support: Ja (über Docker)
*   **Netzwerk-Management:** Ja (konfigurierbar über Docker-Netzwerke)
    *   Konfiguration (Bridge, Host, Overlay): Ja (über Docker)
    *   DNS-Auflösung: Ja (über Docker)
*   **Volume-Management:** Ja
    *   Persistente Speicherung: Ja (empfohlen über Docker Volumes für Daten und Datenbank)
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): Ja (unterstützt)
*   **Orchestrierung:** Teilweise (keine integrierte Orchestrierung, aber gut mit Docker Swarm integrierbar)
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): Ja (Integration)
*   **Sicherheit:** Ja (bietet MFA, rollenbasierte Berechtigungen)
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): Ja (abhängig von der Docker-Host-Konfiguration)
*   **Monitoring & Logging:** Ja (Logs sind über Docker verfügbar, Integration mit Monitoring-Tools möglich)
    *   Tools für Performance/Log-Aggregation: Ja (Integration mit externen Tools)

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** Ja (empfohlen über Reverse Proxy wie Nginx oder Caddy)
*   **Automatisierung (z.B. Let's Encrypt):** Ja (in Kombination mit Reverse Proxies und Let's Encrypt)
*   **Wildcard-Zertifikate:** Ja (abhängig vom Reverse Proxy Setup)
*   **Zentrales Zertifikatsmanagement:** Teilweise (über Reverse Proxy oder externe Tools)

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** Ja (einfache Installation, gute Dokumentation für persönliche Wissensdatenbanken)
*   **Kleine Unternehmen/Startups:** Ja (ideal für interne Dokumentation, Wissensmanagement, Onboarding)
*   **Entwickler:** Ja (Open-Source, API, Docker-basiert)
*   **Bildungseinrichtungen:** Ja (für Kursmaterialien, interne Wikis)

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** Ja (lokale Benutzer, LDAP, SAML 2.0, OpenID Connect, Social Logins wie Google, GitHub, GitLab)
*   **Autorisierungsmodelle (z.B. RBAC):** Ja (Rollenbasierte Zugriffskontrolle, feingranulare Berechtigungen)
*   **Benutzerverwaltung:** Ja (umfassende Benutzer- und Gruppenverwaltung)
*   **Integration mit bestehenden Identitätssystemen:** Ja (LDAP, SAML, OIDC, Social Logins)

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** Ja (effiziente Speicherung von Inhalten)
*   **Performance (I/O, Latenz):** Hoch (abhängig von der zugrunde liegenden Speicherlösung und Datenbank)
*   **Snapshot-Fähigkeiten:** Ja (abhängig vom zugrunde liegenden Dateisystem/Speicherlösung oder Datenbank-Snapshots)
*   **Backup & Restore:** Ja (Datenbank-Backups und Export/Import-Funktionen für Inhalte)
*   **Skalierbarkeit:** Ja (Speicherplatz kann erweitert werden)

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** Ja (MIT-Lizenz)
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** Ja (Fokus auf Dokumentation, Versionierung von Seiten, Kollaboration über Kommentare)
*   **Integration (Anbindung an andere Dienste):** Teilweise (Integrationen über API und Webhooks möglich)
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** Ja (Zugriffskontrolle, MFA, Daten werden auf dem Host gespeichert)
*   **Skalierbarkeit:** Ja (kann große Mengen an Dokumenten verwalten)

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** Ja (volle Kontrolle über den Speicherort und den Zugriff auf Daten)
*   **Anbieterunabhängigkeit:** Ja (durch Open-Source und selbstgehostete Natur)
*   **Transparenz (Quellcode, Funktionsweise):** Ja (vollständig transparent)
*   **Rechtliche Konformität (z.B. DSGVO):** Ja (unterstützt die Einhaltung von Datenschutzbestimmungen durch Selbsthosting)
*   **Föderation:** Nein (keine Föderationsfunktionen)

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** MySQL, MariaDB
*   **Einfache Bereitstellung:** Ja (gut dokumentierte Setups mit Docker Compose)
*   **Management-Tools:** Nein (keine integrierten, aber kompatibel mit externen Tools)
*   **Backup & Recovery:** Ja (Datenbank-Backups sind Teil der Gesamt-Backup-Strategie)
*   **Performance:** Hoch (abhängig von der gewählten Datenbank und Hardware)

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** Ja (kann in Rootless Docker-Umgebungen ausgeführt werden)
*   **Serverless-Funktionen:** Nein (keine native Serverless-Plattform)
*   **Ressourcenverbrauch (Leerlauf):** Gering (für die Kernanwendung)
*   **Sicherheit (reduzierte Privilegien):** Ja (durch Rootless-Ausführung erhöht)

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** Ja (gut dokumentiert für Docker Rootless)
*   **Kompatibilität (Docker-Images/Funktionen):** Ja (volle Kompatibilität mit den meisten Docker-Funktionen)
*   **Performance-Auswirkungen:** Gering (kaum spürbare Performance-Einbußen)
*   **Sicherheitsvorteile:** Ja (erhöhte Sicherheit durch Ausführung als Nicht-Root-Benutzer, Isolation von Host-Systemressourcen)


