# Daten-Erfassungsvorlage für Docker-Apps und OS/ISO-Modelle

## Modellinformationen

*   **Name des Modells:** Paperless-ngx
*   **Typ:** Docker-App
*   **Kurzbeschreibung:** Paperless-ngx ist ein quelloffenes Dokumentenmanagementsystem, das physische Dokumente in ein durchsuchbares Online-Archiv umwandelt, um Papier zu reduzieren und die Organisation zu verbessern.
*   **Offizielle Website/GitHub-Repo:** https://docs.paperless-ngx.com/ / https://github.com/paperless-ngx/paperless-ngx

## 1. Kernfunktionen (Core Features)

*   **Container-Management:** Ja (primär über Docker und Docker Compose bereitgestellt)
    *   Erstellung, Start, Stopp, Löschen: Ja (über Docker)
    *   Docker Compose Integration: Ja (empfohlene Installationsmethode)
*   **Image-Management:** Ja (Docker-Images sind verfügbar und werden verwaltet)
    *   Verwaltung (Pull, Push, Build, Tagging): Ja (über Docker)
    *   Private Registry Support: Ja (über Docker)
*   **Netzwerk-Management:** Ja (konfigurierbar über Docker-Netzwerke)
    *   Konfiguration (Bridge, Host, Overlay): Ja (über Docker)
    *   DNS-Auflösung: Ja (über Docker)
*   **Volume-Management:** Ja
    *   Persistente Speicherung: Ja (empfohlen über Docker Volumes für Dokumente und Datenbank)
    *   Speichertreiber (z.B. Bind Mounts, Named Volumes): Ja (unterstützt)
*   **Orchestrierung:** Teilweise (keine integrierte Orchestrierung, aber gut mit Docker Swarm integrierbar)
    *   Integrierte/Unterstützte Tools (z.B. Docker Swarm, Kubernetes): Ja (Integration)
*   **Sicherheit:** Ja (bietet grundlegende Sicherheitsfunktionen, Fokus auf lokale Bereitstellung)
    *   Grundlegende Sicherheitsfunktionen (z.B. User Namespaces, Seccomp, AppArmor): Ja (abhängig von der Docker-Host-Konfiguration)
*   **Monitoring & Logging:** Ja (Logs sind über Docker verfügbar, Integration mit Monitoring-Tools möglich)
    *   Tools für Performance/Log-Aggregation: Ja (Integration mit externen Tools)

## 2. Netzwerkzertifikate (Network Certificates)

*   **TLS/SSL-Unterstützung:** Teilweise (direkte Unterstützung für selbstsignierte Zertifikate wurde entfernt, primär über Reverse Proxy)
*   **Automatisierung (z.B. Let's Encrypt):** Ja (in Kombination mit Reverse Proxies wie Nginx/Caddy und Let's Encrypt)
*   **Wildcard-Zertifikate:** Ja (abhängig vom Reverse Proxy Setup)
*   **Zentrales Zertifikatsmanagement:** Teilweise (über Reverse Proxy oder externe Tools)

## 3. Zielgruppensegmente (Target Audience Segments)

*   **Heimnutzer/Hobbyisten:** Ja (sehr beliebt für die Digitalisierung von Dokumenten im Haushalt)
*   **Kleine Unternehmen/Startups:** Ja (für die Verwaltung von Rechnungen, Verträgen und anderen Dokumenten)
*   **Entwickler:** Ja (Open-Source-Projekt, Docker-basiert, API verfügbar)
*   **Bildungseinrichtungen:** Teilweise (potenziell für die Verwaltung von Verwaltungsdokumenten)

## 4. Self Hosting Identity

*   **Authentifizierungsmethoden (z.B. Lokal, LDAP, OAuth, SSO):** Ja (lokale Benutzer, LDAP-Integration)
*   **Autorisierungsmodelle (z.B. RBAC):** Ja (Benutzer- und Gruppenverwaltung mit Berechtigungen)
*   **Benutzerverwaltung:** Ja (integrierte Benutzerverwaltung)
*   **Integration mit bestehenden Identitätssystemen:** Ja (LDAP)

## 5. Kennzahlen des Monats Virtuelle Festplatten (Monthly Metrics Virtual Disks)

*   **Speicherplatzverwaltung:** Ja (effiziente Speicherung von Dokumenten)
*   **Performance (I/O, Latenz):** Hoch (abhängig von der zugrunde liegenden Speicherlösung)
*   **Snapshot-Fähigkeiten:** Ja (abhängig vom zugrunde liegenden Dateisystem/Speicherlösung)
*   **Backup & Restore:** Ja (Dokumente und Datenbank können gesichert und wiederhergestellt werden)
*   **Skalierbarkeit:** Ja (Speicherplatz kann erweitert werden)

## 6. Self Cloud Offensafen (Self-Cloud Open Safes)

*   **Open-Source-Status:** Ja (MIT-Lizenz)
*   **Funktionsumfang (Dateisynchronisation, Freigabe, Kollaboration, Versionierung):** Ja (Dokumentenmanagement, OCR, Volltextsuche, Tagging, automatische Klassifizierung)
*   **Integration (Anbindung an andere Dienste):** Teilweise (Fokus auf Dokumentenmanagement, Integrationen über API möglich)
*   **Sicherheit (Verschlüsselung, Zugriffskontrolle):** Ja (Zugriffskontrolle, Verschlüsselung der Daten auf Dateisystemebene)
*   **Skalierbarkeit:** Ja (kann große Mengen an Dokumenten verwalten)

## 7. Digitale Souveränität (Digital Sovereignty)

*   **Datenhoheit:** Ja (volle Kontrolle über den Speicherort und den Zugriff auf Dokumente)
*   **Anbieterunabhängigkeit:** Ja (durch Open-Source und selbstgehostete Natur)
*   **Transparenz (Quellcode, Funktionsweise):** Ja (vollständig transparent)
*   **Rechtliche Konformität (z.B. DSGVO):** Ja (unterstützt die Einhaltung von Datenschutzbestimmungen durch Selbsthosting)
*   **Föderation:** Nein (keine Föderationsfunktionen)

## 8. Database und Databanken (Database and Databases)

*   **Unterstützte Datenbanktypen:** PostgreSQL, SQLite (für einfache Setups)
*   **Einfache Bereitstellung:** Ja (gut dokumentierte Setups mit Docker Compose)
*   **Management-Tools:** Nein (keine integrierten, aber kompatibel mit externen Tools)
*   **Backup & Recovery:** Ja (Datenbank-Backups sind Teil der Gesamt-Backup-Strategie)
*   **Performance:** Hoch (abhängig von der gewählten Datenbank und Hardware)

## 9. SelfHosting RootServerLess (Self-Hosting Rootless/Serverless)

*   **Rootless-Container-Unterstützung:** Ja (kann in Rootless Docker-Umgebungen ausgeführt werden)
*   **Serverless-Funktionen:** Nein (keine native Serverless-Plattform)
*   **Ressourcenverbrauch (Leerlauf):** Gering (für die Kernanwendung)
*   **Sicherheit (reduzierte Privilegien):** Ja (durch Rootless-Ausführung erhöht)

## 10. RootLess (Rootless)

*   **Einfache Konfiguration:** Ja (gut dokumentiert für Docker Rootless)
*   **Kompatibilität (Docker-Images/Funktionen):** Ja (volle Kompatibilität mit den meisten Docker-Funktionen)
*   **Performance-Auswirkungen:** Gering (kaum spürbare Performance-Einbußen)
*   **Sicherheitsvorteile:** Ja (erhöhte Sicherheit durch Ausführung als Nicht-Root-Benutzer, Isolation von Host-Systemressourcen)


