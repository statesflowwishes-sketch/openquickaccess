import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Trophy, Target, Lightbulb, Code, AlertTriangle } from 'lucide-react'
import './App.css'

// Code quality related words for the game
const codeQualityWords = {
  beginner: [
    { word: 'VARIABLE', hint: 'A storage location with an associated name', category: 'Basic Concepts' },
    { word: 'FUNCTION', hint: 'A reusable block of code that performs a specific task', category: 'Basic Concepts' },
    { word: 'LOOP', hint: 'A programming construct that repeats a block of code', category: 'Basic Concepts' },
    { word: 'DEBUG', hint: 'The process of finding and fixing errors in code', category: 'Development Process' },
    { word: 'SYNTAX', hint: 'The set of rules that defines valid constructs in a programming language', category: 'Basic Concepts' }
  ],
  intermediate: [
    { word: 'REFACTOR', hint: 'Restructuring existing code without changing its external behavior', category: 'Clean Code' },
    { word: 'POLYMORPHISM', hint: 'The ability of different classes to be treated as instances of the same type', category: 'OOP Concepts' },
    { word: 'ENCAPSULATION', hint: 'Bundling data and methods that work on that data within one unit', category: 'OOP Concepts' },
    { word: 'INHERITANCE', hint: 'A mechanism where a new class inherits properties from an existing class', category: 'OOP Concepts' },
    { word: 'ABSTRACTION', hint: 'Hiding complex implementation details while showing only essential features', category: 'OOP Concepts' }
  ],
  advanced: [
    { word: 'SINGLERESPONSIBILITY', hint: 'A class should have only one reason to change', category: 'SOLID Principles' },
    { word: 'OPENCLOSEDPRINCIPLE', hint: 'Software entities should be open for extension but closed for modification', category: 'SOLID Principles' },
    { word: 'DEPENDENCYINVERSION', hint: 'High-level modules should not depend on low-level modules', category: 'SOLID Principles' },
    { word: 'DRYPRINCIPLE', hint: 'Don\'t Repeat Yourself - avoid code duplication', category: 'Clean Code' },
    { word: 'KISSPRINCIPLE', hint: 'Keep It Simple, Stupid - favor simplicity over complexity', category: 'Clean Code' }
  ]
}

const errorTypes = [
  { word: 'NULLPOINTER', hint: 'Exception thrown when trying to use a null reference', category: 'Runtime Errors' },
  { word: 'SYNTAXERROR', hint: 'Error in the structure of the code', category: 'Compile-time Errors' },
  { word: 'MEMORYLEAK', hint: 'When a program doesn\'t release memory it no longer needs', category: 'Performance Issues' },
  { word: 'STACKOVERFLOW', hint: 'Error that occurs when the call stack exceeds its limit', category: 'Runtime Errors' },
  { word: 'DEADLOCK', hint: 'Situation where two or more processes are blocked forever', category: 'Concurrency Issues' }
]

function App() {
  const [currentWord, setCurrentWord] = useState(null)
  const [guessedLetters, setGuessedLetters] = useState([])
  const [wrongGuesses, setWrongGuesses] = useState(0)
  const [gameStatus, setGameStatus] = useState('playing') // 'playing', 'won', 'lost'
  const [score, setScore] = useState(0)
  const [streak, setStreak] = useState(0)
  const [difficulty, setDifficulty] = useState('beginner')
  const [showHint, setShowHint] = useState(false)
  const [gameStats, setGameStats] = useState({ gamesPlayed: 0, gamesWon: 0 })

  const maxWrongGuesses = 6
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('')

  // Initialize game
  useEffect(() => {
    startNewGame()
  }, [difficulty])

  const startNewGame = () => {
    let wordPool = []
    
    switch (difficulty) {
      case 'beginner':
        wordPool = codeQualityWords.beginner
        break
      case 'intermediate':
        wordPool = [...codeQualityWords.beginner, ...codeQualityWords.intermediate]
        break
      case 'advanced':
        wordPool = [...codeQualityWords.beginner, ...codeQualityWords.intermediate, ...codeQualityWords.advanced, ...errorTypes]
        break
      default:
        wordPool = codeQualityWords.beginner
    }

    const randomWord = wordPool[Math.floor(Math.random() * wordPool.length)]
    setCurrentWord(randomWord)
    setGuessedLetters([])
    setWrongGuesses(0)
    setGameStatus('playing')
    setShowHint(false)
  }

  const guessLetter = (letter) => {
    if (guessedLetters.includes(letter) || gameStatus !== 'playing') return

    const newGuessedLetters = [...guessedLetters, letter]
    setGuessedLetters(newGuessedLetters)

    if (!currentWord.word.includes(letter)) {
      const newWrongGuesses = wrongGuesses + 1
      setWrongGuesses(newWrongGuesses)
      
      if (newWrongGuesses >= maxWrongGuesses) {
        setGameStatus('lost')
        setStreak(0)
        setGameStats(prev => ({ ...prev, gamesPlayed: prev.gamesPlayed + 1 }))
      }
    } else {
      // Check if word is complete
      const isComplete = currentWord.word.split('').every(char => newGuessedLetters.includes(char))
      if (isComplete) {
        setGameStatus('won')
        const points = calculatePoints()
        setScore(prev => prev + points)
        setStreak(prev => prev + 1)
        setGameStats(prev => ({ 
          gamesPlayed: prev.gamesPlayed + 1, 
          gamesWon: prev.gamesWon + 1 
        }))
      }
    }
  }

  const calculatePoints = () => {
    const basePoints = currentWord.word.length * 10
    const difficultyMultiplier = difficulty === 'beginner' ? 1 : difficulty === 'intermediate' ? 1.5 : 2
    const wrongGuessesDeduction = wrongGuesses * 5
    const streakBonus = streak * 10
    
    return Math.max(0, Math.floor((basePoints * difficultyMultiplier) - wrongGuessesDeduction + streakBonus))
  }

  const getDisplayWord = () => {
    if (!currentWord) return ''
    return currentWord.word.split('').map(letter => 
      guessedLetters.includes(letter) ? letter : '_'
    ).join(' ')
  }

  const getHangmanDisplay = () => {
    const stages = [
      '  +---+\n  |   |\n      |\n      |\n      |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n      |\n      |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n      |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n  |   |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n /|   |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n /|\\  |\n      |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n /|\\  |\n /    |\n=========',
      '  +---+\n  |   |\n  |   |\n  O   |\n /|\\  |\n / \\  |\n========='
    ]
    return stages[wrongGuesses] || stages[0]
  }

  const winRate = gameStats.gamesPlayed > 0 ? Math.round((gameStats.gamesWon / gameStats.gamesPlayed) * 100) : 0

  if (!currentWord) return <div className="flex items-center justify-center min-h-screen">Loading...</div>

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2 flex items-center justify-center gap-2">
            <Code className="text-blue-600" />
            Code Quality Hangman
          </h1>
          <p className="text-gray-600">Learn programming concepts while having fun!</p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <Trophy className="w-6 h-6 mx-auto mb-2 text-yellow-500" />
              <div className="text-2xl font-bold text-gray-800">{score}</div>
              <div className="text-sm text-gray-600">Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="w-6 h-6 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold text-gray-800">{streak}</div>
              <div className="text-sm text-gray-600">Streak</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-800">{winRate}%</div>
              <div className="text-sm text-gray-600">Win Rate</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-800">{gameStats.gamesPlayed}</div>
              <div className="text-sm text-gray-600">Games Played</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Game Area */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Current Challenge</span>
                <Badge variant={difficulty === 'beginner' ? 'default' : difficulty === 'intermediate' ? 'secondary' : 'destructive'}>
                  {difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}
                </Badge>
              </CardTitle>
              <CardDescription>
                Category: {currentWord.category}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Hangman Display */}
              <div className="bg-gray-100 p-4 rounded-lg mb-4">
                <pre className="text-sm font-mono text-center text-gray-700">
                  {getHangmanDisplay()}
                </pre>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-1">
                  <span>Wrong guesses</span>
                  <span>{wrongGuesses}/{maxWrongGuesses}</span>
                </div>
                <Progress value={(wrongGuesses / maxWrongGuesses) * 100} className="h-2" />
              </div>

              {/* Word Display */}
              <div className="text-center mb-6">
                <div className="text-3xl font-mono font-bold text-gray-800 tracking-wider mb-2">
                  {getDisplayWord()}
                </div>
                <div className="text-sm text-gray-600">
                  {currentWord.word.length} letters
                </div>
              </div>

              {/* Game Status */}
              {gameStatus === 'won' && (
                <Alert className="mb-4 border-green-200 bg-green-50">
                  <Trophy className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    Congratulations! You earned {calculatePoints()} points!
                  </AlertDescription>
                </Alert>
              )}

              {gameStatus === 'lost' && (
                <Alert className="mb-4 border-red-200 bg-red-50">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    Game Over! The word was: <strong>{currentWord.word}</strong>
                  </AlertDescription>
                </Alert>
              )}

              {/* Hint */}
              {showHint && (
                <Alert className="mb-4 border-blue-200 bg-blue-50">
                  <Lightbulb className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    <strong>Hint:</strong> {currentWord.hint}
                  </AlertDescription>
                </Alert>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2 mb-4">
                {!showHint && gameStatus === 'playing' && (
                  <Button variant="outline" onClick={() => setShowHint(true)} size="sm">
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Show Hint
                  </Button>
                )}
                {gameStatus !== 'playing' && (
                  <Button onClick={startNewGame} className="flex-1">
                    New Game
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Game Controls</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Difficulty Selector */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Difficulty Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['beginner', 'intermediate', 'advanced'].map((level) => (
                    <Button
                      key={level}
                      variant={difficulty === level ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setDifficulty(level)}
                      disabled={gameStatus === 'playing' && guessedLetters.length > 0}
                    >
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Alphabet */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Choose a Letter
                </label>
                <div className="grid grid-cols-6 gap-2">
                  {alphabet.map((letter) => (
                    <Button
                      key={letter}
                      variant={guessedLetters.includes(letter) ? 
                        (currentWord.word.includes(letter) ? 'default' : 'destructive') : 
                        'outline'
                      }
                      size="sm"
                      onClick={() => guessLetter(letter)}
                      disabled={guessedLetters.includes(letter) || gameStatus !== 'playing'}
                      className="aspect-square"
                    >
                      {letter}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Guessed Letters */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Guessed Letters
                </label>
                <div className="flex flex-wrap gap-1">
                  {guessedLetters.map((letter) => (
                    <Badge
                      key={letter}
                      variant={currentWord.word.includes(letter) ? 'default' : 'destructive'}
                    >
                      {letter}
                    </Badge>
                  ))}
                  {guessedLetters.length === 0 && (
                    <span className="text-sm text-gray-500">None yet</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Learning Section */}
        {gameStatus !== 'playing' && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lightbulb className="text-yellow-500" />
                Learn More
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">About "{currentWord.word}":</h4>
                  <p className="text-gray-600">{currentWord.hint}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Why it matters:</h4>
                  <p className="text-gray-600">
                    Understanding {currentWord.word.toLowerCase()} is crucial for writing clean, maintainable code. 
                    It's part of the {currentWord.category} that every developer should master.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default App

