# Automatisierung und Integration von Tools

## Überblick

Die Automatisierung und Integration von Tools ist ein zentraler Bestandteil des Clean Coding Systems. Diese Phase konzentriert sich auf die Entwicklung von Mechanismen, die eine nahtlose, kontinuierliche und skalierbare Code-Qualitätskontrolle ermöglichen.

## 1. Automatisierungsscripts für Code-Analyse-Tools

### 1.1. Multi-Language Code Analysis Pipeline

```python
# Beispiel: Automatisiertes Code-Analyse-Script
import subprocess
import json
import os
from pathlib import Path
from typing import Dict, List, Any

class CodeAnalyzer:
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.results = {}
        self.supported_tools = {
            'python': ['flake8', 'pylint', 'black', 'mypy'],
            'javascript': ['eslint', 'prettier', 'jshint'],
            'java': ['checkstyle', 'spotbugs', 'pmd'],
            'general': ['sonarqube']
        }
    
    def detect_languages(self) -> List[str]:
        """Erkennt die verwendeten Programmiersprachen im Projekt."""
        language_indicators = {
            'python': ['.py'],
            'javascript': ['.js', '.jsx', '.ts', '.tsx'],
            'java': ['.java'],
            'cpp': ['.cpp', '.hpp', '.c', '.h']
        }
        
        detected = set()
        for file_path in self.project_path.rglob('*'):
            if file_path.is_file():
                suffix = file_path.suffix.lower()
                for lang, extensions in language_indicators.items():
                    if suffix in extensions:
                        detected.add(lang)
        
        return list(detected)
    
    def run_analysis(self) -> Dict[str, Any]:
        """Führt die Code-Analyse für alle erkannten Sprachen durch."""
        languages = self.detect_languages()
        
        for language in languages:
            if language in self.supported_tools:
                self.results[language] = self._analyze_language(language)
        
        # Allgemeine Tools wie SonarQube
        self.results['general'] = self._run_general_analysis()
        
        return self.results
    
    def _analyze_language(self, language: str) -> Dict[str, Any]:
        """Führt sprachspezifische Analyse durch."""
        results = {}
        tools = self.supported_tools[language]
        
        for tool in tools:
            try:
                result = self._run_tool(tool, language)
                results[tool] = result
            except Exception as e:
                results[tool] = {'error': str(e)}
        
        return results
    
    def _run_tool(self, tool: str, language: str) -> Dict[str, Any]:
        """Führt ein spezifisches Tool aus."""
        commands = {
            'flake8': ['flake8', '--format=json', str(self.project_path)],
            'eslint': ['eslint', '--format=json', str(self.project_path)],
            'prettier': ['prettier', '--check', str(self.project_path)]
        }
        
        if tool not in commands:
            return {'error': f'Tool {tool} not configured'}
        
        try:
            result = subprocess.run(
                commands[tool],
                capture_output=True,
                text=True,
                cwd=self.project_path
            )
            
            return {
                'returncode': result.returncode,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'issues': self._parse_output(tool, result.stdout)
            }
        except FileNotFoundError:
            return {'error': f'Tool {tool} not found'}
    
    def _parse_output(self, tool: str, output: str) -> List[Dict[str, Any]]:
        """Parst die Ausgabe der Tools in ein einheitliches Format."""
        if tool in ['flake8', 'eslint'] and output:
            try:
                return json.loads(output)
            except json.JSONDecodeError:
                return [{'raw_output': output}]
        return []
    
    def _run_general_analysis(self) -> Dict[str, Any]:
        """Führt allgemeine Code-Analyse durch."""
        return {
            'complexity_analysis': self._calculate_complexity(),
            'dependency_check': self._check_dependencies(),
            'security_scan': self._security_scan()
        }
    
    def _calculate_complexity(self) -> Dict[str, Any]:
        """Berechnet Code-Komplexität."""
        # Implementierung der Komplexitätsanalyse
        return {'cyclomatic_complexity': 'placeholder'}
    
    def _check_dependencies(self) -> Dict[str, Any]:
        """Überprüft Abhängigkeiten auf Schwachstellen."""
        # Implementierung der Dependency-Analyse
        return {'vulnerable_dependencies': 'placeholder'}
    
    def _security_scan(self) -> Dict[str, Any]:
        """Führt Sicherheitsanalyse durch."""
        # Implementierung des Security-Scans
        return {'security_issues': 'placeholder'}

# Verwendung
if __name__ == "__main__":
    analyzer = CodeAnalyzer("/path/to/project")
    results = analyzer.run_analysis()
    print(json.dumps(results, indent=2))
```

### 1.2. Kontinuierliche Integration Pipeline

```yaml
# .github/workflows/code-quality.yml
name: Code Quality Analysis

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  code-quality:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.9'
    
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '16'
    
    - name: Install Python dependencies
      run: |
        pip install flake8 pylint black mypy
    
    - name: Install Node.js dependencies
      run: |
        npm install -g eslint prettier jshint
    
    - name: Run Code Analysis
      run: |
        python automation/code_analyzer.py
    
    - name: Trigger Hangman Game
      if: failure()
      run: |
        python automation/trigger_game.py --issues-found
    
    - name: Upload Results
      uses: actions/upload-artifact@v3
      with:
        name: code-quality-results
        path: results/
```

## 2. Webhook- und Trigger-Systeme

### 2.1. Git Hook Integration

```python
# git-hooks/pre-commit
#!/usr/bin/env python3
"""
Pre-commit Hook für automatische Code-Qualitätsprüfung
"""

import sys
import subprocess
import json
from pathlib import Path

def get_staged_files():
    """Holt die für Commit vorgemerkten Dateien."""
    result = subprocess.run(
        ['git', 'diff', '--cached', '--name-only'],
        capture_output=True,
        text=True
    )
    return result.stdout.strip().split('\n') if result.stdout.strip() else []

def analyze_staged_files(files):
    """Analysiert nur die geänderten Dateien."""
    issues = []
    
    for file_path in files:
        if file_path.endswith('.py'):
            issues.extend(analyze_python_file(file_path))
        elif file_path.endswith(('.js', '.jsx', '.ts', '.tsx')):
            issues.extend(analyze_javascript_file(file_path))
    
    return issues

def analyze_python_file(file_path):
    """Analysiert eine Python-Datei."""
    issues = []
    
    # Flake8 Analysis
    result = subprocess.run(
        ['flake8', '--format=json', file_path],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0 and result.stdout:
        try:
            flake8_issues = json.loads(result.stdout)
            issues.extend(flake8_issues)
        except json.JSONDecodeError:
            pass
    
    return issues

def analyze_javascript_file(file_path):
    """Analysiert eine JavaScript/TypeScript-Datei."""
    issues = []
    
    # ESLint Analysis
    result = subprocess.run(
        ['eslint', '--format=json', file_path],
        capture_output=True,
        text=True
    )
    
    if result.stdout:
        try:
            eslint_results = json.loads(result.stdout)
            for file_result in eslint_results:
                issues.extend(file_result.get('messages', []))
        except json.JSONDecodeError:
            pass
    
    return issues

def trigger_hangman_game(issues):
    """Löst das Hangman-Spiel aus, wenn Probleme gefunden werden."""
    if not issues:
        return
    
    # Bestimme die Art der Probleme für Wort-Auswahl
    issue_types = set()
    for issue in issues:
        if 'syntax' in issue.get('message', '').lower():
            issue_types.add('syntax_error')
        elif 'undefined' in issue.get('message', '').lower():
            issue_types.add('undefined_variable')
        # Weitere Kategorisierung...
    
    # Starte Hangman-Spiel mit relevanten Begriffen
    subprocess.run([
        'python', 'hangman/trigger.py',
        '--issue-types', ','.join(issue_types)
    ])

def main():
    staged_files = get_staged_files()
    
    if not staged_files:
        sys.exit(0)
    
    print("Analyzing staged files for code quality...")
    issues = analyze_staged_files(staged_files)
    
    if issues:
        print(f"Found {len(issues)} code quality issues:")
        for issue in issues[:5]:  # Zeige nur die ersten 5
            print(f"  - {issue.get('message', 'Unknown issue')}")
        
        if len(issues) > 5:
            print(f"  ... and {len(issues) - 5} more issues")
        
        # Trigger Hangman Game für Lernzwecke
        trigger_hangman_game(issues)
        
        # Entscheide, ob Commit blockiert werden soll
        critical_issues = [i for i in issues if i.get('severity') == 'error']
        if critical_issues:
            print("\nCommit blocked due to critical issues!")
            sys.exit(1)
        else:
            print("\nWarnings found, but commit allowed. Consider fixing these issues.")
    
    print("Code quality check passed!")
    sys.exit(0)

if __name__ == "__main__":
    main()
```

### 2.2. Real-time File Monitoring

```python
# automation/file_monitor.py
"""
Echtzeit-Dateiüberwachung für kontinuierliche Code-Analyse
"""

import time
import json
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from typing import Set, Dict, Any

class CodeFileHandler(FileSystemEventHandler):
    def __init__(self, analyzer, game_trigger):
        self.analyzer = analyzer
        self.game_trigger = game_trigger
        self.monitored_extensions = {'.py', '.js', '.jsx', '.ts', '.tsx', '.java', '.cpp', '.c'}
        self.analysis_queue = set()
        self.last_analysis = {}
    
    def on_modified(self, event):
        if event.is_directory:
            return
        
        file_path = Path(event.src_path)
        if file_path.suffix in self.monitored_extensions:
            self.analysis_queue.add(file_path)
            self._schedule_analysis()
    
    def _schedule_analysis(self):
        """Plant eine verzögerte Analyse, um mehrere schnelle Änderungen zu gruppieren."""
        time.sleep(2)  # Warte 2 Sekunden für weitere Änderungen
        
        if self.analysis_queue:
            files_to_analyze = list(self.analysis_queue)
            self.analysis_queue.clear()
            self._analyze_files(files_to_analyze)
    
    def _analyze_files(self, files: list):
        """Analysiert die geänderten Dateien."""
        for file_path in files:
            try:
                # Verhindere zu häufige Analyse derselben Datei
                if self._should_skip_analysis(file_path):
                    continue
                
                results = self.analyzer.analyze_single_file(str(file_path))
                self.last_analysis[str(file_path)] = time.time()
                
                if results.get('issues'):
                    print(f"Issues found in {file_path.name}: {len(results['issues'])}")
                    self._handle_issues(file_path, results['issues'])
                else:
                    print(f"✓ {file_path.name} - No issues found")
                    
            except Exception as e:
                print(f"Error analyzing {file_path}: {e}")
    
    def _should_skip_analysis(self, file_path: Path) -> bool:
        """Prüft, ob die Analyse übersprungen werden sollte."""
        last_analysis_time = self.last_analysis.get(str(file_path), 0)
        return (time.time() - last_analysis_time) < 10  # Mindestens 10 Sekunden zwischen Analysen
    
    def _handle_issues(self, file_path: Path, issues: list):
        """Behandelt gefundene Code-Probleme."""
        # Kategorisiere Probleme
        issue_categories = self._categorize_issues(issues)
        
        # Trigger Hangman Game für Lernzwecke
        if issue_categories:
            self.game_trigger.trigger_game(issue_categories, file_path)
        
        # Speichere Ergebnisse für Reporting
        self._save_analysis_results(file_path, issues)
    
    def _categorize_issues(self, issues: list) -> Dict[str, int]:
        """Kategorisiert Code-Probleme für das Spiel."""
        categories = {}
        
        for issue in issues:
            message = issue.get('message', '').lower()
            
            if 'syntax' in message:
                categories['syntax_errors'] = categories.get('syntax_errors', 0) + 1
            elif 'undefined' in message or 'not defined' in message:
                categories['undefined_variables'] = categories.get('undefined_variables', 0) + 1
            elif 'complexity' in message:
                categories['complexity_issues'] = categories.get('complexity_issues', 0) + 1
            elif 'import' in message:
                categories['import_issues'] = categories.get('import_issues', 0) + 1
            else:
                categories['general_issues'] = categories.get('general_issues', 0) + 1
        
        return categories
    
    def _save_analysis_results(self, file_path: Path, issues: list):
        """Speichert Analyseergebnisse für Reporting."""
        results_dir = Path('analysis_results')
        results_dir.mkdir(exist_ok=True)
        
        result_file = results_dir / f"{file_path.stem}_{int(time.time())}.json"
        
        with open(result_file, 'w') as f:
            json.dump({
                'file_path': str(file_path),
                'timestamp': time.time(),
                'issues': issues
            }, f, indent=2)

class GameTrigger:
    def __init__(self, hangman_api_url: str):
        self.hangman_api_url = hangman_api_url
        self.trigger_threshold = 3  # Mindestanzahl von Problemen für Spiel-Trigger
    
    def trigger_game(self, issue_categories: Dict[str, int], file_path: Path):
        """Löst das Hangman-Spiel basierend auf gefundenen Problemen aus."""
        total_issues = sum(issue_categories.values())
        
        if total_issues >= self.trigger_threshold:
            # Bestimme den besten Wort-Typ für das Spiel
            primary_category = max(issue_categories.items(), key=lambda x: x[1])
            
            game_config = {
                'trigger_reason': 'code_analysis',
                'file_path': str(file_path),
                'issue_category': primary_category[0],
                'issue_count': primary_category[1],
                'difficulty': self._determine_difficulty(total_issues)
            }
            
            print(f"🎮 Triggering Hangman game for {file_path.name} - {primary_category[0]}")
            # Hier würde die tatsächliche API-Anfrage an das Hangman-Spiel erfolgen
    
    def _determine_difficulty(self, issue_count: int) -> str:
        """Bestimmt die Schwierigkeit basierend auf der Anzahl der Probleme."""
        if issue_count <= 3:
            return 'beginner'
        elif issue_count <= 7:
            return 'intermediate'
        else:
            return 'advanced'

def start_monitoring(project_path: str):
    """Startet die Echtzeit-Überwachung."""
    from code_analyzer import CodeAnalyzer  # Import der vorher definierten Klasse
    
    analyzer = CodeAnalyzer(project_path)
    game_trigger = GameTrigger("http://localhost:3000/api/hangman")
    
    event_handler = CodeFileHandler(analyzer, game_trigger)
    observer = Observer()
    observer.schedule(event_handler, project_path, recursive=True)
    
    observer.start()
    print(f"Started monitoring {project_path} for code changes...")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        print("Monitoring stopped.")
    
    observer.join()

if __name__ == "__main__":
    import sys
    project_path = sys.argv[1] if len(sys.argv) > 1 else "."
    start_monitoring(project_path)
```

## 3. Automatische Update-Mechanismen

### 3.1. Tool Update Manager

```python
# automation/update_manager.py
"""
Automatisches Update-Management für Code-Analyse-Tools
"""

import subprocess
import json
import requests
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timedelta

class ToolUpdateManager:
    def __init__(self, config_file: str = "tool_config.json"):
        self.config_file = Path(config_file)
        self.tools_config = self._load_config()
        self.update_log = []
    
    def _load_config(self) -> Dict:
        """Lädt die Tool-Konfiguration."""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return json.load(f)
        
        # Standard-Konfiguration
        return {
            "tools": {
                "eslint": {
                    "type": "npm",
                    "package": "eslint",
                    "check_interval_days": 7,
                    "auto_update": True
                },
                "flake8": {
                    "type": "pip",
                    "package": "flake8",
                    "check_interval_days": 7,
                    "auto_update": True
                },
                "prettier": {
                    "type": "npm",
                    "package": "prettier",
                    "check_interval_days": 7,
                    "auto_update": True
                },
                "sonarqube": {
                    "type": "docker",
                    "image": "sonarqube:latest",
                    "check_interval_days": 30,
                    "auto_update": False
                }
            },
            "last_check": {}
        }
    
    def _save_config(self):
        """Speichert die Tool-Konfiguration."""
        with open(self.config_file, 'w') as f:
            json.dump(self.tools_config, f, indent=2)
    
    def check_for_updates(self) -> Dict[str, Dict]:
        """Überprüft alle Tools auf verfügbare Updates."""
        updates_available = {}
        
        for tool_name, tool_config in self.tools_config["tools"].items():
            if self._should_check_tool(tool_name, tool_config):
                update_info = self._check_tool_update(tool_name, tool_config)
                if update_info:
                    updates_available[tool_name] = update_info
                
                # Aktualisiere letzten Check-Zeitpunkt
                self.tools_config["last_check"][tool_name] = datetime.now().isoformat()
        
        self._save_config()
        return updates_available
    
    def _should_check_tool(self, tool_name: str, tool_config: Dict) -> bool:
        """Prüft, ob ein Tool auf Updates überprüft werden sollte."""
        last_check = self.tools_config["last_check"].get(tool_name)
        if not last_check:
            return True
        
        last_check_date = datetime.fromisoformat(last_check)
        check_interval = timedelta(days=tool_config.get("check_interval_days", 7))
        
        return datetime.now() - last_check_date > check_interval
    
    def _check_tool_update(self, tool_name: str, tool_config: Dict) -> Optional[Dict]:
        """Überprüft ein spezifisches Tool auf Updates."""
        tool_type = tool_config["type"]
        
        try:
            if tool_type == "npm":
                return self._check_npm_update(tool_config["package"])
            elif tool_type == "pip":
                return self._check_pip_update(tool_config["package"])
            elif tool_type == "docker":
                return self._check_docker_update(tool_config["image"])
        except Exception as e:
            self.update_log.append({
                "tool": tool_name,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            })
        
        return None
    
    def _check_npm_update(self, package: str) -> Optional[Dict]:
        """Überprüft NPM-Package auf Updates."""
        # Aktuelle Version
        result = subprocess.run(
            ['npm', 'list', package, '--depth=0', '--json'],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            return None
        
        current_info = json.loads(result.stdout)
        current_version = current_info.get("dependencies", {}).get(package, {}).get("version")
        
        # Neueste Version
        result = subprocess.run(
            ['npm', 'view', package, 'version'],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            return None
        
        latest_version = result.stdout.strip()
        
        if current_version != latest_version:
            return {
                "current_version": current_version,
                "latest_version": latest_version,
                "update_command": f"npm update {package}"
            }
        
        return None
    
    def _check_pip_update(self, package: str) -> Optional[Dict]:
        """Überprüft PIP-Package auf Updates."""
        result = subprocess.run(
            ['pip', 'list', '--outdated', '--format=json'],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            return None
        
        outdated_packages = json.loads(result.stdout)
        
        for pkg in outdated_packages:
            if pkg["name"].lower() == package.lower():
                return {
                    "current_version": pkg["version"],
                    "latest_version": pkg["latest_version"],
                    "update_command": f"pip install --upgrade {package}"
                }
        
        return None
    
    def _check_docker_update(self, image: str) -> Optional[Dict]:
        """Überprüft Docker-Image auf Updates."""
        # Vereinfachte Implementierung - in der Praxis würde man Docker Registry APIs verwenden
        result = subprocess.run(
            ['docker', 'pull', image],
            capture_output=True,
            text=True
        )
        
        if "Downloaded newer image" in result.stdout:
            return {
                "current_version": "unknown",
                "latest_version": "pulled",
                "update_command": f"docker pull {image}"
            }
        
        return None
    
    def apply_updates(self, updates: Dict[str, Dict], auto_only: bool = True) -> Dict[str, bool]:
        """Wendet verfügbare Updates an."""
        results = {}
        
        for tool_name, update_info in updates.items():
            tool_config = self.tools_config["tools"][tool_name]
            
            if auto_only and not tool_config.get("auto_update", False):
                results[tool_name] = False
                continue
            
            try:
                command = update_info["update_command"].split()
                result = subprocess.run(command, capture_output=True, text=True)
                
                success = result.returncode == 0
                results[tool_name] = success
                
                self.update_log.append({
                    "tool": tool_name,
                    "action": "update",
                    "success": success,
                    "command": update_info["update_command"],
                    "output": result.stdout if success else result.stderr,
                    "timestamp": datetime.now().isoformat()
                })
                
            except Exception as e:
                results[tool_name] = False
                self.update_log.append({
                    "tool": tool_name,
                    "action": "update",
                    "success": False,
                    "error": str(e),
                    "timestamp": datetime.now().isoformat()
                })
        
        return results
    
    def get_update_log(self) -> List[Dict]:
        """Gibt das Update-Log zurück."""
        return self.update_log
    
    def schedule_updates(self):
        """Plant regelmäßige Update-Checks."""
        updates = self.check_for_updates()
        
        if updates:
            print(f"Found updates for {len(updates)} tools:")
            for tool, info in updates.items():
                print(f"  {tool}: {info['current_version']} -> {info['latest_version']}")
            
            # Automatische Updates anwenden
            results = self.apply_updates(updates, auto_only=True)
            
            successful_updates = [tool for tool, success in results.items() if success]
            if successful_updates:
                print(f"Successfully updated: {', '.join(successful_updates)}")
        else:
            print("All tools are up to date.")

# Verwendung
if __name__ == "__main__":
    manager = ToolUpdateManager()
    manager.schedule_updates()
```

## 4. API-Integration und Skalierung

### 4.1. REST API für Systemintegration

```python
# api/clean_code_api.py
"""
REST API für das Clean Coding System
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime
from pathlib import Path

app = Flask(__name__)
CORS(app)  # Ermöglicht Cross-Origin Requests

# Simulierte Datenbank (in der Praxis würde eine echte DB verwendet)
analysis_results = {}
game_sessions = {}
system_stats = {
    "total_analyses": 0,
    "total_games": 0,
    "active_projects": 0
}

@app.route('/api/health', methods=['GET'])
def health_check():
    """Gesundheitscheck für das System."""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    })

@app.route('/api/analyze', methods=['POST'])
def analyze_code():
    """Startet eine Code-Analyse."""
    data = request.get_json()
    
    if not data or 'project_path' not in data:
        return jsonify({"error": "project_path is required"}), 400
    
    project_path = data['project_path']
    analysis_id = f"analysis_{int(datetime.now().timestamp())}"
    
    # Simuliere Code-Analyse (in der Praxis würde hier die echte Analyse laufen)
    from automation.code_analyzer import CodeAnalyzer
    
    try:
        analyzer = CodeAnalyzer(project_path)
        results = analyzer.run_analysis()
        
        analysis_results[analysis_id] = {
            "id": analysis_id,
            "project_path": project_path,
            "timestamp": datetime.now().isoformat(),
            "results": results,
            "status": "completed"
        }
        
        system_stats["total_analyses"] += 1
        
        # Trigger Hangman Game wenn Probleme gefunden wurden
        if _has_issues(results):
            game_session = _trigger_hangman_game(analysis_id, results)
            analysis_results[analysis_id]["game_session"] = game_session["id"]
        
        return jsonify(analysis_results[analysis_id])
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/analysis/<analysis_id>', methods=['GET'])
def get_analysis(analysis_id):
    """Holt Analyseergebnisse."""
    if analysis_id not in analysis_results:
        return jsonify({"error": "Analysis not found"}), 404
    
    return jsonify(analysis_results[analysis_id])

@app.route('/api/hangman/start', methods=['POST'])
def start_hangman_game():
    """Startet ein Hangman-Spiel."""
    data = request.get_json()
    
    game_id = f"game_{int(datetime.now().timestamp())}"
    
    game_session = {
        "id": game_id,
        "timestamp": datetime.now().isoformat(),
        "difficulty": data.get("difficulty", "beginner"),
        "category": data.get("category", "basic_concepts"),
        "trigger_reason": data.get("trigger_reason", "manual"),
        "status": "active",
        "score": 0,
        "guesses": [],
        "current_word": _select_word(data.get("difficulty", "beginner"), data.get("category"))
    }
    
    game_sessions[game_id] = game_session
    system_stats["total_games"] += 1
    
    return jsonify({
        "game_id": game_id,
        "word_pattern": _get_word_pattern(game_session["current_word"]["word"], []),
        "category": game_session["current_word"]["category"],
        "hint": game_session["current_word"]["hint"]
    })

@app.route('/api/hangman/<game_id>/guess', methods=['POST'])
def make_guess(game_id):
    """Macht einen Buchstaben-Tipp im Hangman-Spiel."""
    if game_id not in game_sessions:
        return jsonify({"error": "Game not found"}), 404
    
    data = request.get_json()
    letter = data.get("letter", "").upper()
    
    if not letter or len(letter) != 1:
        return jsonify({"error": "Invalid letter"}), 400
    
    game = game_sessions[game_id]
    
    if game["status"] != "active":
        return jsonify({"error": "Game is not active"}), 400
    
    if letter in game["guesses"]:
        return jsonify({"error": "Letter already guessed"}), 400
    
    game["guesses"].append(letter)
    
    word = game["current_word"]["word"]
    is_correct = letter in word
    
    if is_correct:
        # Prüfe ob Wort komplett ist
        if all(char in game["guesses"] for char in word):
            game["status"] = "won"
            game["score"] = _calculate_score(game)
    else:
        wrong_guesses = len([g for g in game["guesses"] if g not in word])
        if wrong_guesses >= 6:
            game["status"] = "lost"
    
    return jsonify({
        "game_id": game_id,
        "letter": letter,
        "is_correct": is_correct,
        "word_pattern": _get_word_pattern(word, game["guesses"]),
        "wrong_guesses": len([g for g in game["guesses"] if g not in word]),
        "status": game["status"],
        "score": game.get("score", 0)
    })

@app.route('/api/stats', methods=['GET'])
def get_system_stats():
    """Holt Systemstatistiken."""
    return jsonify(system_stats)

@app.route('/api/projects', methods=['GET'])
def list_projects():
    """Listet überwachte Projekte auf."""
    # Simulierte Projektliste
    projects = [
        {
            "id": "project_1",
            "name": "Web App Frontend",
            "path": "/projects/webapp-frontend",
            "language": "javascript",
            "last_analysis": "2024-01-15T10:30:00",
            "status": "healthy"
        },
        {
            "id": "project_2", 
            "name": "API Backend",
            "path": "/projects/api-backend",
            "language": "python",
            "last_analysis": "2024-01-15T09:45:00",
            "status": "issues_found"
        }
    ]
    
    return jsonify(projects)

def _has_issues(results):
    """Prüft ob Analyseergebnisse Probleme enthalten."""
    for language_results in results.values():
        if isinstance(language_results, dict):
            for tool_results in language_results.values():
                if isinstance(tool_results, dict) and tool_results.get('issues'):
                    return True
    return False

def _trigger_hangman_game(analysis_id, results):
    """Löst ein Hangman-Spiel basierend auf Analyseergebnissen aus."""
    # Bestimme Kategorie basierend auf gefundenen Problemen
    category = "basic_concepts"  # Standard
    difficulty = "beginner"
    
    # Analysiere Probleme für bessere Kategorisierung
    issue_count = 0
    for language_results in results.values():
        if isinstance(language_results, dict):
            for tool_results in language_results.values():
                if isinstance(tool_results, dict) and tool_results.get('issues'):
                    issue_count += len(tool_results['issues'])
    
    if issue_count > 10:
        difficulty = "advanced"
    elif issue_count > 5:
        difficulty = "intermediate"
    
    game_data = {
        "difficulty": difficulty,
        "category": category,
        "trigger_reason": f"code_analysis_{analysis_id}"
    }
    
    # Simuliere Spielstart
    game_id = f"game_{int(datetime.now().timestamp())}"
    game_session = {
        "id": game_id,
        "analysis_id": analysis_id,
        "triggered_by": "code_analysis",
        "timestamp": datetime.now().isoformat()
    }
    
    game_sessions[game_id] = game_session
    return game_session

def _select_word(difficulty, category):
    """Wählt ein Wort für das Hangman-Spiel aus."""
    # Vereinfachte Wort-Auswahl (in der Praxis aus Datenbank)
    words = {
        "beginner": [
            {"word": "LOOP", "hint": "A programming construct that repeats a block of code", "category": "Basic Concepts"},
            {"word": "VARIABLE", "hint": "A storage location with an associated name", "category": "Basic Concepts"}
        ],
        "intermediate": [
            {"word": "REFACTOR", "hint": "Restructuring existing code without changing its external behavior", "category": "Clean Code"}
        ],
        "advanced": [
            {"word": "SINGLERESPONSIBILITY", "hint": "A class should have only one reason to change", "category": "SOLID Principles"}
        ]
    }
    
    import random
    return random.choice(words.get(difficulty, words["beginner"]))

def _get_word_pattern(word, guesses):
    """Erstellt das Wort-Muster für das Hangman-Spiel."""
    return ' '.join([char if char in guesses else '_' for char in word])

def _calculate_score(game):
    """Berechnet die Punkte für ein Hangman-Spiel."""
    word_length = len(game["current_word"]["word"])
    wrong_guesses = len([g for g in game["guesses"] if g not in game["current_word"]["word"]])
    
    base_score = word_length * 10
    penalty = wrong_guesses * 5
    
    return max(0, base_score - penalty)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
```

Diese umfassende Automatisierungs- und Integrationslösung bietet:

1. **Vollautomatische Code-Analyse** mit Multi-Language-Support
2. **Echtzeit-Überwachung** von Code-Änderungen
3. **Intelligente Spiel-Trigger** basierend auf gefundenen Problemen
4. **Automatisches Update-Management** für alle Tools
5. **REST API** für nahtlose Integration
6. **Skalierbare Architektur** für große Projekte

Das System kann kontinuierlich im Hintergrund laufen und bietet sowohl automatisierte als auch interaktive Lernmöglichkeiten für Entwickler.

