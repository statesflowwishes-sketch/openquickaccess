## Beispielhafte, abstrahierte Tabelle zur regelbasierten Partnerintegration

| Partnerkategorie | Zugriffsart | Ressourcentyp | Berechtigungsstufe |
|------------------|-------------|---------------|--------------------|
| Software-Anbieter | Lesezugriff | Code-Basis    | Standard           |
| Hardware-Hersteller | Schreibzugriff | Spezifikationen | Erweitert          |
| Telekommunikation | Lesezugriff | Schnittstellen | Standard           |
| Finanzdienstleister | Lesezugriff | Audit-Logs    | Sensitiv           |
| Forschungsinstitute | Schreibzugriff | Datenmodelle  | Erweitert          |
| Behörden          | Lesezugriff | Richtlinien   | Standard           |


