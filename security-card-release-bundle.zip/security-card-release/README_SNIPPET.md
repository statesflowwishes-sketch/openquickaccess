<!-- Social card -->
<picture>
  <source media="(prefers-reduced-data: no-preference)" srcset="security-card-release/social-1200x630.webp" type="image/webp">
  <img src="security-card-release/social-1200x630.png" alt="Grafik mit dunkelblauem Hintergrund: In der Mitte ein stilisiertes Schloss-Symbol als Schild, umgeben von konzentrischen Linien und kleinen Personen-Avataren mit Security-Symbolen. Text: „I improved the security posture of my open source project in less than 15 minutes. You can do it too, no security expertise needed! Visit securitylab.github.com“. Footer: „GitHub Security Lab“.">
</picture>

<!-- Open Graph / Twitter -->
<!-- put these in your website <head> -->
<meta property="og:title" content="Improve your OSS security posture in minutes">
<meta property="og:description" content="CodeQL, Dependabot, Policies &amp; SBOMs – kleine Schritte, große Wirkung.">
<meta property="og:image" content="security-card-release/social-1200x630.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Improve your OSS security posture in minutes">
<meta name="twitter:description" content="CodeQL, Dependabot, Policies &amp; SBOMs – kleine Schritte, große Wirkung.">
<meta name="twitter:image" content="security-card-release/social-1200x630.png">