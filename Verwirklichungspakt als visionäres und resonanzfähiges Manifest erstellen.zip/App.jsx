import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { motion } from 'framer-motion'
import { Heart, Globe, Lightbulb, Users, Leaf, BookOpen, Palette, Building, Stethoscope, FlaskConical, Plus } from 'lucide-react'
import './App.css'

const expertiseAreas = [
  { id: 'tech', label: 'Technologie & Innovation', icon: Lightbulb },
  { id: 'sustainability', label: 'Nachhaltigkeit & Umwelt', icon: Leaf },
  { id: 'education', label: 'Bildung & Entwicklung', icon: BookOpen },
  { id: 'arts', label: 'Kunst & Kultur', icon: Palette },
  { id: 'business', label: 'Wirtschaft & Unternehmertum', icon: Building },
  { id: 'social', label: 'Soziale Gerechtigkeit', icon: Users },
  { id: 'health', label: 'Gesundheit & Wohlbefinden', icon: Stethoscope },
  { id: 'science', label: 'Wissenschaft & Forschung', icon: FlaskConical },
]

function App() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    country: '',
    city: '',
    organization: '',
    position: '',
    expertiseAreas: [],
    otherExpertise: '',
    contribution: '',
    vision: '',
    projects: '',
    acceptPrinciples: false,
    activeParticipation: false,
    newsletter: false,
    collaboration: false,
    comments: ''
  })

  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleExpertiseToggle = (areaId) => {
    setFormData(prev => ({
      ...prev,
      expertiseAreas: prev.expertiseAreas.includes(areaId)
        ? prev.expertiseAreas.filter(id => id !== areaId)
        : [...prev.expertiseAreas, areaId]
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would typically send the data to a server
    console.log('Form submitted:', formData)
    setIsSubmitted(true)
  }

  const isStepValid = (step) => {
    switch (step) {
      case 1:
        return formData.fullName && formData.email && formData.country
      case 2:
        return formData.expertiseAreas.length > 0
      case 3:
        return formData.acceptPrinciples && formData.activeParticipation
      default:
        return true
    }
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full"
        >
          <Card className="text-center">
            <CardHeader>
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <Heart className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl">Willkommen in der Bewegung!</CardTitle>
              <CardDescription>
                Vielen Dank für Ihr Engagement. Sie sind nun Teil des Verwirklichungspaktes.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Sie erhalten in Kürze eine Bestätigungs-E-Mail mit weiteren Informationen.
              </p>
              <Button onClick={() => window.location.reload()} className="w-full">
                Neue Einreichung
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Verwirklichungspakt
              </h1>
              <p className="text-sm text-muted-foreground">EID PACT MANIFEST</p>
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="max-w-4xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-2">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                currentStep >= step 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-200 text-gray-600'
              }`}>
                {step}
              </div>
              {step < 3 && (
                <div className={`w-20 h-1 mx-2 ${
                  currentStep > step ? 'bg-blue-600' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>Persönliche Daten</span>
          <span>Engagement</span>
          <span>Verpflichtung</span>
        </div>
      </div>

      {/* Form */}
      <div className="max-w-4xl mx-auto px-4 pb-8">
        <form onSubmit={handleSubmit}>
          {/* Step 1: Personal Information */}
          {currentStep === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Persönliche Informationen</CardTitle>
                  <CardDescription>
                    Teilen Sie uns mit, wer Sie sind und wie wir Sie erreichen können.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Vollständiger Name *</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        placeholder="Ihr vollständiger Name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-Mail-Adresse *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="ihre.email@beispiel.de"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefonnummer</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        placeholder="+49 123 456789"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="country">Land/Region *</Label>
                      <Input
                        id="country"
                        value={formData.country}
                        onChange={(e) => handleInputChange('country', e.target.value)}
                        placeholder="Deutschland"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="city">Stadt</Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        placeholder="Ihre Stadt"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="organization">Organisation/Unternehmen</Label>
                      <Input
                        id="organization"
                        value={formData.organization}
                        onChange={(e) => handleInputChange('organization', e.target.value)}
                        placeholder="Ihr Unternehmen oder Organisation"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="position">Position/Rolle</Label>
                    <Input
                      id="position"
                      value={formData.position}
                      onChange={(e) => handleInputChange('position', e.target.value)}
                      placeholder="Ihre berufliche Position oder Rolle"
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 2: Engagement and Vision */}
          {currentStep === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Ihr Engagement und Ihre Vision</CardTitle>
                  <CardDescription>
                    Erzählen Sie uns von Ihren Interessen und wie Sie zur Verwirklichung beitragen möchten.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <Label>Bereiche der Expertise/Interesse *</Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {expertiseAreas.map((area) => {
                        const Icon = area.icon
                        const isSelected = formData.expertiseAreas.includes(area.id)
                        return (
                          <motion.div
                            key={area.id}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <div
                              className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                isSelected
                                  ? 'border-blue-500 bg-blue-50'
                                  : 'border-gray-200 hover:border-gray-300'
                              }`}
                              onClick={() => handleExpertiseToggle(area.id)}
                            >
                              <div className="flex items-center gap-3">
                                <Icon className={`w-5 h-5 ${isSelected ? 'text-blue-600' : 'text-gray-600'}`} />
                                <span className={`text-sm font-medium ${isSelected ? 'text-blue-900' : 'text-gray-700'}`}>
                                  {area.label}
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        )
                      })}
                    </div>
                    {formData.expertiseAreas.includes('other') && (
                      <div className="space-y-2">
                        <Label htmlFor="otherExpertise">Andere (bitte spezifizieren)</Label>
                        <Input
                          id="otherExpertise"
                          value={formData.otherExpertise}
                          onChange={(e) => handleInputChange('otherExpertise', e.target.value)}
                          placeholder="Beschreiben Sie Ihren Bereich"
                        />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contribution">Wie möchten Sie zur Verwirklichung beitragen?</Label>
                    <Textarea
                      id="contribution"
                      value={formData.contribution}
                      onChange={(e) => handleInputChange('contribution', e.target.value)}
                      placeholder="Beschreiben Sie, wie Sie sich einbringen möchten..."
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="vision">Ihre Vision für die Zukunft</Label>
                    <Textarea
                      id="vision"
                      value={formData.vision}
                      onChange={(e) => handleInputChange('vision', e.target.value)}
                      placeholder="Teilen Sie Ihre Vision für eine bessere Zukunft..."
                      rows={4}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="projects">Spezifische Projekte oder Initiativen</Label>
                    <Textarea
                      id="projects"
                      value={formData.projects}
                      onChange={(e) => handleInputChange('projects', e.target.value)}
                      placeholder="Welche Projekte oder Initiativen möchten Sie unterstützen?"
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Step 3: Commitment */}
          {currentStep === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Ihre Verpflichtung</CardTitle>
                  <CardDescription>
                    Bestätigen Sie Ihr Engagement für die Prinzipien des Verwirklichungspaktes.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="acceptPrinciples"
                        checked={formData.acceptPrinciples}
                        onCheckedChange={(checked) => handleInputChange('acceptPrinciples', checked)}
                        required
                      />
                      <div className="space-y-1">
                        <Label htmlFor="acceptPrinciples" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Bestätigung der Prinzipien *
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Ich bestätige, dass ich die Prinzipien des Verwirklichungspaktes gelesen, verstanden und akzeptiert habe.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="activeParticipation"
                        checked={formData.activeParticipation}
                        onCheckedChange={(checked) => handleInputChange('activeParticipation', checked)}
                        required
                      />
                      <div className="space-y-1">
                        <Label htmlFor="activeParticipation" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Bereitschaft zur aktiven Teilnahme *
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Ich erkläre mich bereit, aktiv zur Verwirklichung der in diesem Pakt dargelegten Vision beizutragen.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="newsletter"
                        checked={formData.newsletter}
                        onCheckedChange={(checked) => handleInputChange('newsletter', checked)}
                      />
                      <div className="space-y-1">
                        <Label htmlFor="newsletter" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Newsletter-Anmeldung
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Ich möchte über Neuigkeiten und Entwicklungen der Verwirklichungspakt-Bewegung informiert werden.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="collaboration"
                        checked={formData.collaboration}
                        onCheckedChange={(checked) => handleInputChange('collaboration', checked)}
                      />
                      <div className="space-y-1">
                        <Label htmlFor="collaboration" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                          Kontakt für Zusammenarbeit
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Ich bin offen für Kontakt bezüglich möglicher Zusammenarbeit und Projekte.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="comments">Kommentare oder Nachrichten</Label>
                    <Textarea
                      id="comments"
                      value={formData.comments}
                      onChange={(e) => handleInputChange('comments', e.target.value)}
                      placeholder="Haben Sie noch etwas hinzuzufügen?"
                      rows={4}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <Button
              type="button"
              variant="outline"
              onClick={() => setCurrentStep(prev => Math.max(1, prev - 1))}
              disabled={currentStep === 1}
            >
              Zurück
            </Button>
            
            {currentStep < 3 ? (
              <Button
                type="button"
                onClick={() => setCurrentStep(prev => prev + 1)}
                disabled={!isStepValid(currentStep)}
              >
                Weiter
              </Button>
            ) : (
              <Button
                type="submit"
                disabled={!isStepValid(currentStep)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                Pakt unterzeichnen
              </Button>
            )}
          </div>
        </form>
      </div>
    </div>
  )
}

export default App

