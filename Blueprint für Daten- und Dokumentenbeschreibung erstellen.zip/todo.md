- [x] Analysiere die Struktur der Dokumente und identifiziere Hauptthemen.
- [x] Kategorisiere die Dokumente basierend auf ihrem Inhalt und Zweck.
- [x] Extrahiere Schlüsselinformationen und Konzepte aus beiden Dokumenten.
- [x] Bereite eine Zusammenfassung der Analyse vor.

