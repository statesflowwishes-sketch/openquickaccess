import base64
import markdown

# Funktion zum Einbetten von Bildern als Base64
def image_to_base64(path):
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

# Pfade zu den Dateien
form_html_path = "/home/ubuntu/praevention_formular_erweitert.html"
dashboard_html_path = "/home/ubuntu/datenformulare_dashboard.html"
handbook_md_path = "/home/ubuntu/praeventions_system_handbuch.md"
business_md_path = "/home/ubuntu/business_information_system.md"
output_html_path = "/home/ubuntu/praeventions_system_komplett.html"

# Bilderpfade
image_paths = {
    "risk_matrix.png": "/home/ubuntu/risk_matrix.png",
    "implementation_timeline.png": "/home/ubuntu/implementation_timeline.png",
    "system_architecture.png": "/home/ubuntu/system_architecture.png",
    "kpi_dashboard.png": "/home/ubuntu/kpi_dashboard.png",
    "market_analysis.png": "/home/ubuntu/market_analysis.png",
}

# Inhalte lesen
with open(form_html_path, "r") as f:
    form_html = f.read()

with open(dashboard_html_path, "r") as f:
    dashboard_html = f.read()

with open(handbook_md_path, "r") as f:
    handbook_md = f.read()

with open(business_md_path, "r") as f:
    business_md = f.read()

# Markdown in HTML umwandeln
handbook_html = markdown.markdown(handbook_md)
business_html = markdown.markdown(business_md)

# Bilder in Base64 umwandeln
base64_images = {name: image_to_base64(path) for name, path in image_paths.items()}

# Extrahieren der relevanten Teile aus den HTML-Dateien
from bs4 import BeautifulSoup

form_soup = BeautifulSoup(form_html, "html.parser")
form_content = form_soup.find("div", {"id": "content"}).prettify()
form_script = form_soup.find("script").prettify()

dashboard_soup = BeautifulSoup(dashboard_html, "html.parser")
dashboard_content = dashboard_soup.find("main").prettify()
dashboard_script = dashboard_soup.find_all("script")[-1].prettify() # get the last script tag

# Ersetzen der Bild-Pfade im Dashboard-Inhalt mit Base64-Daten
for name, b64_data in base64_images.items():
    dashboard_content = dashboard_content.replace(f'src="{name}"', f'src="data:image/png;base64,{b64_data}"')

# HTML-Vorlage
final_html = f"""<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Präventions-System: Umfassende Dokumentation & Tools</title>
<style>
{form_soup.find('style').text}

/* Additional styles for embedded content */
.markdown-content h1, .markdown-content h2, .markdown-content h3 {{
    border-bottom: 1px solid var(--border);
    padding-bottom: 8px;
    margin-top: 24px;
}}
</style>
</head>
<body>
<header class="appbar" role="banner">
  <div class="brand">
    <div class="logo" aria-hidden="true"></div>
    <h1>Präventions-System: Umfassende Dokumentation & Tools</h1>
  </div>
</header>

<main>
  <nav class="toc" aria-label="Inhaltsverzeichnis">
    <details open class="block">
      <summary>📋 Inhaltsverzeichnis</summary>
      <ul>
        <li><a href="#dashboard">Dashboard & Visualisierungen</a></li>
        <li><a href="#formular">Präventions-Formular</a></li>
        <li><a href="#handbuch">Präventions-System Handbuch</a></li>
        <li><a href="#business_info">Business Information System</a></li>
      </ul>
    </details>
  </nav>

  <div id="content">
    <section class="chapter" id="dashboard">
      <h2><span class="chip">Dashboard</span> Dashboard & Visualisierungen</h2>
      {dashboard_content}
    </section>

    <section class="chapter" id="formular">
      <h2><span class="chip">Formular</span> Präventions-Formular System</h2>
      {form_content}
    </section>

    <section class="chapter" id="handbuch">
      <h2><span class="chip">Handbuch</span> Präventions-System Handbuch</h2>
      <div class="markdown-content">{handbook_html}</div>
    </section>

    <section class="chapter" id="business_info">
      <h2><span class="chip">Business</span> Business Information System</h2>
      <div class="markdown-content">{business_html}</div>
    </section>
  </div>
</main>

{form_script}
{dashboard_script}

</body>
</html>
"""

# Speichern der finalen HTML-Datei
with open(output_html_path, "w") as f:
    f.write(final_html)

print(f"Die zusammengeführte Website wurde unter {output_html_path} gespeichert.")
      gespeichert.")


