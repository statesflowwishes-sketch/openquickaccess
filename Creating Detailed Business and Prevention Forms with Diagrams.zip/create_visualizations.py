#!/usr/bin/env python3
"""
Präventions-System Datenvisualisierungen
Erstellt umfassende Diagramme und Grafiken für das Präventions-Formular-System
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.patches import FancyBboxPatch
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
import warnings
warnings.filterwarnings('ignore')

# Set style and font
plt.style.use('dark_background')
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

# Define color palette
colors = {
    'primary': '#77e1ff',
    'secondary': '#b990ff', 
    'accent': '#ffc857',
    'success': '#4ee89a',
    'warning': '#ffd166',
    'danger': '#ff6b6b',
    'dark': '#0a0e13',
    'light': '#e8eef7',
    'muted': '#a9b3c7'
}

def create_risk_matrix():
    """Erstellt eine Risikobewertungsmatrix"""
    fig, ax = plt.subplots(figsize=(12, 8))
    fig.patch.set_facecolor(colors['dark'])
    ax.set_facecolor(colors['dark'])
    
    # Risk matrix data
    risks = [
        ('Systemausfall kritischer Infrastruktur', 4, 5, 'Technisch'),
        ('Datenschutzverletzung', 3, 4, 'Rechtlich'),
        ('Nutzerakzeptanz niedrig', 4, 3, 'Sozial'),
        ('Regulatorische Änderungen', 2, 4, 'Rechtlich'),
        ('Technologische Obsoleszenz', 3, 3, 'Technisch'),
        ('Cybersecurity-Angriffe', 3, 5, 'Technisch'),
        ('Budgetüberschreitung', 4, 2, 'Finanziell'),
        ('Personalengpässe', 3, 2, 'Organisational'),
        ('Marktkonkurrenz', 4, 3, 'Strategisch'),
        ('Ethische Bedenken', 2, 4, 'Ethisch')
    ]
    
    # Create scatter plot
    for risk, prob, impact, category in risks:
        color_map = {
            'Technisch': colors['primary'],
            'Rechtlich': colors['danger'],
            'Sozial': colors['success'],
            'Finanziell': colors['warning'],
            'Organisational': colors['secondary'],
            'Strategisch': colors['accent'],
            'Ethisch': colors['muted']
        }
        
        ax.scatter(prob, impact, s=200, c=color_map[category], 
                  alpha=0.7, edgecolors='white', linewidth=2)
        
        # Add risk labels with offset
        ax.annotate(risk, (prob, impact), xytext=(5, 5), 
                   textcoords='offset points', fontsize=9,
                   color=colors['light'], ha='left')
    
    # Add risk zones
    ax.axhspan(0, 2, xmin=0, xmax=0.4, alpha=0.2, color=colors['success'], label='Niedrig')
    ax.axhspan(2, 4, xmin=0.4, xmax=0.8, alpha=0.2, color=colors['warning'], label='Mittel')
    ax.axhspan(4, 5, xmin=0.8, xmax=1, alpha=0.2, color=colors['danger'], label='Hoch')
    
    ax.set_xlabel('Eintrittswahrscheinlichkeit', color=colors['light'])
    ax.set_ylabel('Auswirkung', color=colors['light'])
    ax.set_title('Risikobewertungsmatrix - Präventions-System', 
                color=colors['light'], fontweight='bold', pad=20)
    
    ax.set_xlim(0.5, 5.5)
    ax.set_ylim(0.5, 5.5)
    ax.grid(True, alpha=0.3, color=colors['muted'])
    
    # Create custom legend
    legend_elements = [plt.scatter([], [], c=color, s=100, label=cat) 
                      for cat, color in {
                          'Technisch': colors['primary'],
                          'Rechtlich': colors['danger'],
                          'Sozial': colors['success'],
                          'Finanziell': colors['warning'],
                          'Organisational': colors['secondary'],
                          'Strategisch': colors['accent'],
                          'Ethisch': colors['muted']
                      }.items()]
    
    ax.legend(handles=legend_elements, loc='upper left', 
             facecolor=colors['dark'], edgecolor=colors['muted'])
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/risk_matrix.png', dpi=300, bbox_inches='tight',
                facecolor=colors['dark'], edgecolor='none')
    plt.close()

def create_implementation_timeline():
    """Erstellt einen Implementierungsfahrplan"""
    fig, ax = plt.subplots(figsize=(14, 8))
    fig.patch.set_facecolor(colors['dark'])
    ax.set_facecolor(colors['dark'])
    
    # Timeline data
    phases = [
        ('Konzeptvalidierung', '2025-Q1', '2025-Q2', colors['primary']),
        ('Prototypentwicklung', '2025-Q2', '2025-Q3', colors['secondary']),
        ('Pilotprojekt Start', '2025-Q3', '2025-Q4', colors['accent']),
        ('Evaluierung', '2025-Q4', '2026-Q1', colors['success']),
        ('Skalierung', '2026-Q1', '2026-Q3', colors['warning']),
        ('Markteinführung', '2026-Q3', '2027-Q1', colors['danger'])
    ]
    
    # Convert quarters to numeric values
    quarter_map = {
        '2025-Q1': 1, '2025-Q2': 2, '2025-Q3': 3, '2025-Q4': 4,
        '2026-Q1': 5, '2026-Q2': 6, '2026-Q3': 7, '2026-Q4': 8,
        '2027-Q1': 9, '2027-Q2': 10
    }
    
    y_pos = np.arange(len(phases))
    
    for i, (phase, start, end, color) in enumerate(phases):
        start_num = quarter_map[start]
        end_num = quarter_map[end]
        duration = end_num - start_num
        
        # Create timeline bar
        bar = ax.barh(i, duration, left=start_num, height=0.6, 
                     color=color, alpha=0.8, edgecolor='white', linewidth=1)
        
        # Add phase label
        ax.text(start_num + duration/2, i, phase, 
               ha='center', va='center', fontweight='bold',
               color='white', fontsize=11)
        
        # Add duration label
        ax.text(end_num + 0.1, i, f'{duration}Q', 
               ha='left', va='center', color=colors['muted'], fontsize=9)
    
    # Customize axes
    ax.set_yticks(y_pos)
    ax.set_yticklabels([])
    ax.set_xlabel('Zeitraum', color=colors['light'])
    ax.set_title('Implementierungsfahrplan - Präventions-System', 
                color=colors['light'], fontweight='bold', pad=20)
    
    # Set x-axis labels
    quarters = ['2025-Q1', '2025-Q2', '2025-Q3', '2025-Q4', 
               '2026-Q1', '2026-Q2', '2026-Q3', '2026-Q4', '2027-Q1']
    ax.set_xticks(range(1, len(quarters) + 1))
    ax.set_xticklabels(quarters, rotation=45, ha='right', color=colors['light'])
    
    ax.grid(True, axis='x', alpha=0.3, color=colors['muted'])
    ax.set_xlim(0.5, 9.5)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/implementation_timeline.png', dpi=300, bbox_inches='tight',
                facecolor=colors['dark'], edgecolor='none')
    plt.close()

def create_system_architecture():
    """Erstellt ein Systemarchitektur-Diagramm"""
    fig, ax = plt.subplots(figsize=(14, 10))
    fig.patch.set_facecolor(colors['dark'])
    ax.set_facecolor(colors['dark'])
    
    # Define components and their positions
    components = {
        'Sensoren': (2, 8, colors['primary']),
        'Edge Computing': (6, 8, colors['secondary']),
        'KI-Algorithmen': (10, 8, colors['accent']),
        'Datenverarbeitung': (2, 6, colors['success']),
        'Präventive Logik': (6, 6, colors['warning']),
        'Aktoren': (10, 6, colors['danger']),
        'User Interface': (2, 4, colors['primary']),
        'Kommunikation': (6, 4, colors['secondary']),
        'Cloud Services': (10, 4, colors['accent']),
        'Sicherheit': (4, 2, colors['success']),
        'Monitoring': (8, 2, colors['warning'])
    }
    
    # Draw components
    for comp, (x, y, color) in components.items():
        # Create rounded rectangle
        rect = FancyBboxPatch((x-0.8, y-0.4), 1.6, 0.8,
                             boxstyle="round,pad=0.1",
                             facecolor=color, alpha=0.8,
                             edgecolor='white', linewidth=2)
        ax.add_patch(rect)
        
        # Add text
        ax.text(x, y, comp, ha='center', va='center',
               fontweight='bold', color='white', fontsize=10)
    
    # Draw connections
    connections = [
        ('Sensoren', 'Edge Computing'),
        ('Edge Computing', 'KI-Algorithmen'),
        ('Sensoren', 'Datenverarbeitung'),
        ('Datenverarbeitung', 'Präventive Logik'),
        ('Präventive Logik', 'Aktoren'),
        ('KI-Algorithmen', 'Präventive Logik'),
        ('User Interface', 'Kommunikation'),
        ('Kommunikation', 'Cloud Services'),
        ('Präventive Logik', 'Kommunikation'),
        ('Sicherheit', 'Monitoring'),
        ('Kommunikation', 'Sicherheit'),
        ('Cloud Services', 'Monitoring')
    ]
    
    for start, end in connections:
        x1, y1, _ = components[start]
        x2, y2, _ = components[end]
        
        ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                   arrowprops=dict(arrowstyle='->', color=colors['muted'], 
                                 lw=2, alpha=0.7))
    
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 10)
    ax.set_aspect('equal')
    ax.axis('off')
    
    ax.set_title('Systemarchitektur - Präventions-System', 
                color=colors['light'], fontweight='bold', fontsize=16, pad=20)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/system_architecture.png', dpi=300, bbox_inches='tight',
                facecolor=colors['dark'], edgecolor='none')
    plt.close()

def create_kpi_dashboard():
    """Erstellt ein KPI-Dashboard"""
    fig = plt.figure(figsize=(16, 12))
    fig.patch.set_facecolor(colors['dark'])
    
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.3, wspace=0.3)
    
    # KPI 1: Unfallreduktion
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_facecolor(colors['dark'])
    
    months = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun']
    before = [45, 52, 38, 41, 47, 39]
    after = [12, 15, 8, 11, 13, 9]
    
    x = np.arange(len(months))
    width = 0.35
    
    ax1.bar(x - width/2, before, width, label='Vor System', color=colors['danger'], alpha=0.8)
    ax1.bar(x + width/2, after, width, label='Nach System', color=colors['success'], alpha=0.8)
    
    ax1.set_title('Unfallreduktion', color=colors['light'], fontweight='bold')
    ax1.set_xlabel('Monat', color=colors['light'])
    ax1.set_ylabel('Anzahl Unfälle', color=colors['light'])
    ax1.set_xticks(x)
    ax1.set_xticklabels(months, color=colors['light'])
    ax1.tick_params(colors=colors['light'])
    ax1.legend(facecolor=colors['dark'], edgecolor=colors['muted'])
    ax1.grid(True, alpha=0.3, color=colors['muted'])
    
    # KPI 2: Energieeffizienz
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.set_facecolor(colors['dark'])
    
    categories = ['Beleuchtung', 'Heizung', 'Kühlung', 'Sicherheit']
    efficiency = [85, 78, 92, 88]
    
    bars = ax2.bar(categories, efficiency, color=[colors['primary'], colors['secondary'], 
                                                 colors['accent'], colors['success']], alpha=0.8)
    
    ax2.set_title('Energieeffizienz (%)', color=colors['light'], fontweight='bold')
    ax2.set_ylabel('Effizienz (%)', color=colors['light'])
    ax2.set_ylim(0, 100)
    ax2.tick_params(colors=colors['light'])
    ax2.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add value labels on bars
    for bar, value in zip(bars, efficiency):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                f'{value}%', ha='center', va='bottom', color=colors['light'], fontweight='bold')
    
    # KPI 3: Nutzerzufriedenheit
    ax3 = fig.add_subplot(gs[0, 2])
    ax3.set_facecolor(colors['dark'])
    
    satisfaction_data = [5, 15, 25, 35, 20]  # 1-5 stars distribution
    labels = ['1★', '2★', '3★', '4★', '5★']
    colors_pie = [colors['danger'], colors['warning'], colors['muted'], 
                  colors['primary'], colors['success']]
    
    wedges, texts, autotexts = ax3.pie(satisfaction_data, labels=labels, colors=colors_pie,
                                      autopct='%1.1f%%', startangle=90)
    
    ax3.set_title('Nutzerzufriedenheit', color=colors['light'], fontweight='bold')
    
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
    
    # KPI 4: Systemverfügbarkeit
    ax4 = fig.add_subplot(gs[1, :])
    ax4.set_facecolor(colors['dark'])
    
    days = pd.date_range('2025-01-01', periods=30, freq='D')
    uptime = np.random.normal(99.5, 0.5, 30)
    uptime = np.clip(uptime, 95, 100)
    
    ax4.plot(days, uptime, color=colors['primary'], linewidth=3, alpha=0.8)
    ax4.fill_between(days, uptime, alpha=0.3, color=colors['primary'])
    
    ax4.set_title('Systemverfügbarkeit (30 Tage)', color=colors['light'], fontweight='bold')
    ax4.set_xlabel('Datum', color=colors['light'])
    ax4.set_ylabel('Verfügbarkeit (%)', color=colors['light'])
    ax4.set_ylim(95, 100)
    ax4.tick_params(colors=colors['light'])
    ax4.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add SLA line
    ax4.axhline(y=99, color=colors['warning'], linestyle='--', 
               label='SLA Minimum (99%)', alpha=0.8)
    ax4.legend(facecolor=colors['dark'], edgecolor=colors['muted'])
    
    # KPI 5: Kostenersparnis
    ax5 = fig.add_subplot(gs[2, 0])
    ax5.set_facecolor(colors['dark'])
    
    quarters = ['Q1', 'Q2', 'Q3', 'Q4']
    savings = [125000, 180000, 220000, 285000]
    
    ax5.plot(quarters, savings, marker='o', linewidth=3, markersize=8,
            color=colors['success'], markerfacecolor=colors['success'])
    
    ax5.set_title('Kumulative Kostenersparnis (€)', color=colors['light'], fontweight='bold')
    ax5.set_xlabel('Quartal', color=colors['light'])
    ax5.set_ylabel('Ersparnis (€)', color=colors['light'])
    ax5.tick_params(colors=colors['light'])
    ax5.grid(True, alpha=0.3, color=colors['muted'])
    
    # Format y-axis as currency
    ax5.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'€{x/1000:.0f}K'))
    
    # KPI 6: Präventionsrate
    ax6 = fig.add_subplot(gs[2, 1])
    ax6.set_facecolor(colors['dark'])
    
    prevention_types = ['Unfälle', 'Brände', 'Einbrüche', 'Ausfälle']
    prevented = [95, 88, 92, 85]
    
    bars = ax6.barh(prevention_types, prevented, 
                   color=[colors['danger'], colors['warning'], 
                         colors['primary'], colors['secondary']], alpha=0.8)
    
    ax6.set_title('Präventionsrate (%)', color=colors['light'], fontweight='bold')
    ax6.set_xlabel('Verhinderte Ereignisse (%)', color=colors['light'])
    ax6.set_xlim(0, 100)
    ax6.tick_params(colors=colors['light'])
    ax6.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add value labels
    for bar, value in zip(bars, prevented):
        ax6.text(value + 1, bar.get_y() + bar.get_height()/2,
                f'{value}%', ha='left', va='center', color=colors['light'], fontweight='bold')
    
    # KPI 7: ROI Entwicklung
    ax7 = fig.add_subplot(gs[2, 2])
    ax7.set_facecolor(colors['dark'])
    
    months_roi = ['M1', 'M3', 'M6', 'M9', 'M12']
    roi = [-15, -5, 12, 28, 45]
    colors_roi = [colors['danger'] if x < 0 else colors['success'] for x in roi]
    
    bars = ax7.bar(months_roi, roi, color=colors_roi, alpha=0.8)
    
    ax7.set_title('ROI Entwicklung (%)', color=colors['light'], fontweight='bold')
    ax7.set_xlabel('Monate nach Implementierung', color=colors['light'])
    ax7.set_ylabel('ROI (%)', color=colors['light'])
    ax7.axhline(y=0, color=colors['muted'], linestyle='-', alpha=0.5)
    ax7.tick_params(colors=colors['light'])
    ax7.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add value labels
    for bar, value in zip(bars, roi):
        y_pos = value + (2 if value >= 0 else -4)
        ax7.text(bar.get_x() + bar.get_width()/2, y_pos,
                f'{value}%', ha='center', va='bottom' if value >= 0 else 'top',
                color=colors['light'], fontweight='bold')
    
    plt.suptitle('KPI Dashboard - Präventions-System Performance', 
                color=colors['light'], fontsize=18, fontweight='bold', y=0.98)
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/kpi_dashboard.png', dpi=300, bbox_inches='tight',
                facecolor=colors['dark'], edgecolor='none')
    plt.close()

def create_market_analysis():
    """Erstellt Marktanalyse-Diagramme"""
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
    fig.patch.set_facecolor(colors['dark'])
    
    for ax in [ax1, ax2, ax3, ax4]:
        ax.set_facecolor(colors['dark'])
    
    # Market Size Growth
    years = np.array([2024, 2025, 2026, 2027, 2028, 2029, 2030])
    market_size = np.array([12, 18, 28, 42, 65, 95, 140])  # Billions USD
    
    ax1.plot(years, market_size, marker='o', linewidth=4, markersize=8,
            color=colors['primary'], markerfacecolor=colors['primary'])
    ax1.fill_between(years, market_size, alpha=0.3, color=colors['primary'])
    
    ax1.set_title('Marktgröße Präventive Systeme', color=colors['light'], fontweight='bold')
    ax1.set_xlabel('Jahr', color=colors['light'])
    ax1.set_ylabel('Marktgröße (Mrd. USD)', color=colors['light'])
    ax1.tick_params(colors=colors['light'])
    ax1.grid(True, alpha=0.3, color=colors['muted'])
    
    # Market Segments
    segments = ['Smart Cities', 'Automotive', 'Buildings', 'Consumer', 'Industrial']
    segment_sizes = [45, 28, 35, 22, 15]
    colors_segments = [colors['primary'], colors['secondary'], colors['accent'], 
                      colors['success'], colors['warning']]
    
    wedges, texts, autotexts = ax2.pie(segment_sizes, labels=segments, colors=colors_segments,
                                      autopct='%1.1f%%', startangle=90)
    
    ax2.set_title('Marktsegmente (2025)', color=colors['light'], fontweight='bold')
    
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
    
    # Regional Distribution
    regions = ['Nordamerika', 'Europa', 'Asien-Pazifik', 'Rest der Welt']
    market_share = [35, 30, 25, 10]
    
    bars = ax3.bar(regions, market_share, 
                  color=[colors['primary'], colors['secondary'], 
                        colors['accent'], colors['muted']], alpha=0.8)
    
    ax3.set_title('Regionale Marktverteilung (%)', color=colors['light'], fontweight='bold')
    ax3.set_ylabel('Marktanteil (%)', color=colors['light'])
    ax3.tick_params(colors=colors['light'])
    ax3.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add value labels
    for bar, value in zip(bars, market_share):
        ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                f'{value}%', ha='center', va='bottom', color=colors['light'], fontweight='bold')
    
    # Technology Adoption Curve
    adoption_phases = ['Innovatoren', 'Frühe Anwender', 'Frühe Mehrheit', 
                      'Späte Mehrheit', 'Nachzügler']
    adoption_percentages = [2.5, 13.5, 34, 34, 16]
    
    x_pos = np.arange(len(adoption_phases))
    bars = ax4.bar(x_pos, adoption_percentages,
                  color=[colors['danger'], colors['warning'], colors['success'], 
                        colors['primary'], colors['muted']], alpha=0.8)
    
    ax4.set_title('Technologie-Adoptionskurve', color=colors['light'], fontweight='bold')
    ax4.set_xlabel('Adopter-Kategorien', color=colors['light'])
    ax4.set_ylabel('Marktanteil (%)', color=colors['light'])
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels(adoption_phases, rotation=45, ha='right', color=colors['light'])
    ax4.tick_params(colors=colors['light'])
    ax4.grid(True, alpha=0.3, color=colors['muted'])
    
    # Add value labels
    for bar, value in zip(bars, adoption_percentages):
        ax4.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                f'{value}%', ha='center', va='bottom', color=colors['light'], fontweight='bold')
    
    plt.tight_layout()
    plt.savefig('/home/ubuntu/market_analysis.png', dpi=300, bbox_inches='tight',
                facecolor=colors['dark'], edgecolor='none')
    plt.close()

def main():
    """Hauptfunktion zum Erstellen aller Visualisierungen"""
    print("Erstelle Präventions-System Visualisierungen...")
    
    print("1. Risikobewertungsmatrix...")
    create_risk_matrix()
    
    print("2. Implementierungsfahrplan...")
    create_implementation_timeline()
    
    print("3. Systemarchitektur...")
    create_system_architecture()
    
    print("4. KPI Dashboard...")
    create_kpi_dashboard()
    
    print("5. Marktanalyse...")
    create_market_analysis()
    
    print("Alle Visualisierungen erfolgreich erstellt!")
    print("Dateien gespeichert:")
    print("- risk_matrix.png")
    print("- implementation_timeline.png") 
    print("- system_architecture.png")
    print("- kpi_dashboard.png")
    print("- market_analysis.png")

if __name__ == "__main__":
    main()

