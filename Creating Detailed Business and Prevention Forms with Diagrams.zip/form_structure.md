
## Struktur des HTML-Formulars (Basierend auf Praeventives_Gigantisches_Formular.html)

Das HTML-Formular wird in die folgenden Hauptkapitel unterteilt, die jeweils spezifische Eingabefelder enthalten:

### 0. Deckblatt & Leitbild
- **Organisation / Initiative:** Textfeld
- **Dokumenten-ID:** Textfeld
- **Erstellungsdatum:** Datumsfeld
- **Version:** Textfeld
- **Status:** Dropdown (Entwurf, In Arbeit, Final, Archiviert)
- **Leitgedanke / Motto:** Textarea

### 1. Stammdaten & Geltungsbereich
- **Projektname:** Textfeld
- **Projektbeschreibung:** Textarea
- **Geltungsbereich:** Textarea
- **Verantwortliche(r):** Textfeld
- **Kontakt:** Textfeld

### 2. Ästhetische Systemgestaltung (Software/Oberflächen)
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 3. Urbane Licht- & Infrastruktur
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 4. Symbiotisches Fahren
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 5. Festival@Home & Klangräume
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 6. Schlaf & Ergonomie
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 7. Gebäudeintelligenz & Brandschutz
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 8. Produkt-Selbstschutz (Alkohol/Tabak)
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 9. Kindersicherheit im Haushalt
- **Ziele:** Textarea
- **Risiken:** Textarea
- **Maßnahmen:** Textarea
- **KPIs:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 10. Ethik, Datenschutz & Governance
- **Prinzipien:** Textarea
- **Privacy-by-Design:** Textarea
- **Governance:** Textarea

### 11. Risikoanalyse & Präventionsmatrix
- **Top-Risiken (Liste):** Textarea
- **Kontrollen / Präventionsmaßnahmen:** Textarea
- **Restrisiko-Bewertung:** Textarea
- **Skalendefinition:** Textfeld

### 12. Implementierungsfahrplan
- **Meilensteine:** Textarea
- **Ressourcen:** Textarea
- **Projekt-Risiken:** Textarea
- **Kommunikation:** Textarea
- **Status:** Dropdown (offen, in Arbeit, pilotiert, erledigt)

### 13. Zustimmung, Freigaben & Signaturen
- **Rechtliche Hinweise:** Textarea
- **Zertifikats-/Referenzangaben:** Textarea
- **Unterzeichner:in:** Textfeld
- **Ort:** Textfeld
- **Datum:** Datumsfeld
- **Integritäts-Hash (SHA-256):** Textfeld (readonly)

Jeder Abschnitt (außer Deckblatt und Signaturen) wird die Felder für Ziele, Risiken, Maßnahmen, KPIs und Status enthalten, um eine konsistente Datenerfassung zu gewährleisten. Die Dropdown-Optionen für 'Status' werden 'offen', 'in Arbeit', 'pilotiert' und 'erledigt' sein. Die Implementierung wird auch die Export- und Importfunktionen für JSON-Daten sowie die Hash-Generierung umfassen.

