#!/bin/bash

# Environment Setup Script
# Installs common dependencies needed for the AI/ML tools

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            OS="debian"
        elif [ -f /etc/redhat-release ]; then
            OS="redhat"
        else
            OS="linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]]; then
        OS="windows"
    else
        OS="unknown"
    fi
}

# Install Docker
install_docker() {
    log_info "Installing Docker..."
    
    case $OS in
        "debian")
            # Ubuntu/Debian
            sudo apt-get update
            sudo apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release
            curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
            echo "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
            sudo apt-get update
            sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
            ;;
        "redhat")
            # CentOS/RHEL/Fedora
            sudo dnf install -y dnf-plugins-core
            sudo dnf config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo
            sudo dnf install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
            ;;
        "macos")
            if command -v brew >/dev/null 2>&1; then
                brew install --cask docker
            else
                log_warning "Please install Docker Desktop from https://www.docker.com/products/docker-desktop"
                return 1
            fi
            ;;
        *)
            log_warning "Automatic Docker installation not supported for your OS."
            log_info "Please install Docker manually from https://docs.docker.com/get-docker/"
            return 1
            ;;
    esac
    
    # Start Docker service
    if [[ "$OS" != "macos" ]]; then
        sudo systemctl start docker
        sudo systemctl enable docker
        sudo usermod -aG docker $USER
        log_warning "Please log out and log back in for Docker group changes to take effect."
    fi
    
    log_success "Docker installation completed!"
}

# Install Python and pip
install_python() {
    log_info "Installing Python and pip..."
    
    case $OS in
        "debian")
            sudo apt-get update
            sudo apt-get install -y python3 python3-pip python3-venv
            ;;
        "redhat")
            sudo dnf install -y python3 python3-pip
            ;;
        "macos")
            if command -v brew >/dev/null 2>&1; then
                brew install python3
            else
                log_warning "Please install Python from https://www.python.org/downloads/"
                return 1
            fi
            ;;
        *)
            log_warning "Please install Python 3 manually from https://www.python.org/downloads/"
            return 1
            ;;
    esac
    
    log_success "Python installation completed!"
}

# Install Node.js
install_nodejs() {
    log_info "Installing Node.js..."
    
    case $OS in
        "debian")
            curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
            sudo apt-get install -y nodejs
            ;;
        "redhat")
            curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
            sudo dnf install -y nodejs
            ;;
        "macos")
            if command -v brew >/dev/null 2>&1; then
                brew install node
            else
                log_warning "Please install Node.js from https://nodejs.org/"
                return 1
            fi
            ;;
        *)
            log_warning "Please install Node.js manually from https://nodejs.org/"
            return 1
            ;;
    esac
    
    log_success "Node.js installation completed!"
}

# Install Git
install_git() {
    log_info "Installing Git..."
    
    case $OS in
        "debian")
            sudo apt-get update
            sudo apt-get install -y git
            ;;
        "redhat")
            sudo dnf install -y git
            ;;
        "macos")
            if command -v brew >/dev/null 2>&1; then
                brew install git
            else
                # Git is usually pre-installed on macOS
                if ! command -v git >/dev/null 2>&1; then
                    log_warning "Please install Git from https://git-scm.com/download/mac"
                    return 1
                fi
            fi
            ;;
        *)
            log_warning "Please install Git manually from https://git-scm.com/"
            return 1
            ;;
    esac
    
    log_success "Git installation completed!"
}

# Main function
main() {
    echo "=========================================="
    echo "  Environment Setup for AI/ML Tools"
    echo "=========================================="
    echo
    
    detect_os
    log_info "Detected OS: $OS"
    
    echo "This script will install common dependencies:"
    echo "- Git"
    echo "- Python 3 and pip"
    echo "- Node.js and npm"
    echo "- Docker and Docker Compose"
    echo
    
    read -p "Do you want to continue? (y/N): " confirm
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        log_info "Installation cancelled."
        exit 0
    fi
    
    # Install dependencies
    install_git
    install_python
    install_nodejs
    install_docker
    
    echo
    log_success "Environment setup completed!"
    echo
    echo "You can now run the main installation script:"
    echo "./scripts/install.sh"
    echo
    
    if [[ "$OS" != "macos" ]]; then
        log_warning "Please log out and log back in for Docker group changes to take effect."
    fi
}

main "$@"

