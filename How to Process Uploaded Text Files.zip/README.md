# MIT 6.S191 Deep Learning Course Setup

This guide helps you set up the MIT Introduction to Deep Learning (6.S191) course materials locally.

## Overview

The MIT 6.S191 course provides hands-on labs covering various deep learning topics including computer vision, natural language processing, and biology applications.

## Prerequisites

- Python 3.8 or higher
- Git
- 8GB+ RAM recommended
- GPU support optional but recommended for faster training

## Installation Steps

### 1. Clone the Repository

```bash
git clone https://github.com/abusufyanvu/6S191_MIT_DeepLearning.git
cd 6S191_MIT_DeepLearning
```

### 2. Set Up Python Environment

#### Option A: Using Conda (Recommended)

```bash
# Create a new conda environment
conda create -n mit-deeplearning python=3.9
conda activate mit-deeplearning

# Install required packages
conda install jupyter numpy matplotlib pandas
pip install mitdeeplearning tensorflow torch torchvision
```

#### Option B: Using pip and venv

```bash
# Create virtual environment
python -m venv mit-deeplearning
source mit-deeplearning/bin/activate  # On Windows: mit-deeplearning\Scripts\activate

# Install required packages
pip install jupyter numpy matplotlib pandas
pip install mitdeeplearning tensorflow torch torchvision
```

### 3. Install Additional Dependencies

```bash
# Install the MIT deep learning package
pip install mitdeeplearning

# Install other common ML libraries
pip install scikit-learn seaborn plotly opencv-python
```

### 4. Start Jupyter Notebook

```bash
# Navigate to the course directory
cd 6S191_MIT_DeepLearning

# Start Jupyter
jupyter notebook
```

## Course Structure

The course includes several lab notebooks:
- Lab 1: Introduction to TensorFlow
- Lab 2: Computer Vision
- Lab 3: Natural Language Processing
- Lab 4: Deep Generative Modeling
- Lab 5: Deep Reinforcement Learning

## Running Labs

1. Open Jupyter Notebook in your browser (usually http://localhost:8888)
2. Navigate to the lab you want to run
3. Execute cells sequentially
4. Follow the instructions in each notebook

## GPU Support (Optional)

For faster training, you can enable GPU support:

### For TensorFlow:
```bash
pip install tensorflow-gpu
```

### For PyTorch:
Visit https://pytorch.org/get-started/locally/ and select your CUDA version.

## Troubleshooting

### Common Issues:

1. **Import Error for mitdeeplearning**
   ```bash
   pip install --upgrade mitdeeplearning
   ```

2. **TensorFlow/PyTorch Version Conflicts**
   ```bash
   pip install tensorflow==2.12.0 torch==1.13.0
   ```

3. **Jupyter Kernel Issues**
   ```bash
   python -m ipykernel install --user --name=mit-deeplearning
   ```

4. **Memory Issues**
   - Reduce batch sizes in the notebooks
   - Close other applications
   - Consider using Google Colab as an alternative

## Alternative: Google Colab

If local setup is problematic, you can run the labs in Google Colab:

1. Go to https://colab.research.google.com/
2. Upload the notebook files
3. Install required packages in the first cell:
   ```python
   !pip install mitdeeplearning
   ```

## Resources

- [Official MIT 6.S191 Website](http://introtodeeplearning.com/)
- [Course Videos](https://www.youtube.com/playlist?list=PLtBw6njQRU-rwp5__7C0oIVt26ZgjG9NI)
- [TensorFlow Documentation](https://www.tensorflow.org/)
- [PyTorch Documentation](https://pytorch.org/docs/)

## Support

For course-specific questions, refer to the official MIT course forums or documentation. For technical setup issues, check the troubleshooting section above.

