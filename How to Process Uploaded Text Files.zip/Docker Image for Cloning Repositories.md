
## Docker Image for Cloning Repositories

This Docker image contains a script to clone a list of specified GitHub repositories.

### Building the Docker Image

To build the Docker image, run the following command in your terminal:

```
docker build -t repo-cloner .
```

### Running the Docker Container

To run the Docker container and clone the repositories, use the following command:

```
docker run -v $(pwd)/cloned_repos:/app repo-cloner
```

This will mount a directory named `cloned_repos` in your current working directory and clone the repositories into it.


