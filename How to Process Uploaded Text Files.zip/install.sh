#!/bin/bash

# AI/ML Repository Installation Package
# Master Installation Script
# 
# This script provides an interactive installation for the AI/ML repositories
# and tools specified in your request.

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check system requirements
check_requirements() {
    log_info "Checking system requirements..."
    
    local missing_deps=()
    
    # Check for essential tools
    if ! command_exists git; then
        missing_deps+=("git")
    fi
    
    if ! command_exists curl; then
        missing_deps+=("curl")
    fi
    
    # Check for Docker (optional but recommended)
    if ! command_exists docker; then
        log_warning "Docker not found. Docker-based applications will not be available."
    fi
    
    if ! command_exists docker-compose; then
        log_warning "Docker Compose not found. Orchestrated deployment will not be available."
    fi
    
    # Check for Python (for many tools)
    if ! command_exists python3; then
        missing_deps+=("python3")
    fi
    
    if ! command_exists pip3; then
        missing_deps+=("python3-pip")
    fi
    
    # Check for Node.js (for some tools)
    if ! command_exists node; then
        log_warning "Node.js not found. Some applications may not be available."
    fi
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        log_error "Missing required dependencies: ${missing_deps[*]}"
        log_info "Please install the missing dependencies and run this script again."
        
        # Provide installation suggestions based on OS
        if command_exists apt; then
            log_info "On Ubuntu/Debian, run: sudo apt update && sudo apt install ${missing_deps[*]}"
        elif command_exists yum; then
            log_info "On CentOS/RHEL, run: sudo yum install ${missing_deps[*]}"
        elif command_exists brew; then
            log_info "On macOS, run: brew install ${missing_deps[*]}"
        fi
        
        exit 1
    fi
    
    log_success "System requirements check passed!"
}

# Display menu
show_menu() {
    echo
    echo "=========================================="
    echo "  AI/ML Repository Installation Package"
    echo "=========================================="
    echo
    echo "Choose installation option:"
    echo
    echo "1) Docker Applications (Recommended)"
    echo "   - Cloud Monitor (Web-GUI for server monitoring)"
    echo "   - AI Code Translator (AI-powered code translation)"
    echo
    echo "2) Setup Guides (Interactive setup for libraries/plugins)"
    echo "   - MIT Deep Learning Course"
    echo "   - IDE Plugins (InCoder, CodeSeek)"
    echo "   - Laravel OpenAI Wrapper"
    echo "   - Alembic Database Migration Tool"
    echo "   - Development Environment Dotfiles"
    echo
    echo "3) View Explanations (Information about non-installable items)"
    echo
    echo "4) Install Everything (Docker apps + setup guides)"
    echo
    echo "5) Exit"
    echo
}

# Install Docker applications
install_docker_apps() {
    log_info "Installing Docker-based applications..."
    
    if ! command_exists docker || ! command_exists docker-compose; then
        log_error "Docker and Docker Compose are required for this option."
        log_info "Please install Docker and Docker Compose first:"
        log_info "- Docker: https://docs.docker.com/get-docker/"
        log_info "- Docker Compose: https://docs.docker.com/compose/install/"
        return 1
    fi
    
    # Check if we're in the right directory
    if [ ! -f "docker-compose.yml" ]; then
        log_error "docker-compose.yml not found. Please run this script from the installation package directory."
        return 1
    fi
    
    # Create .env file for environment variables
    if [ ! -f ".env" ]; then
        log_info "Creating environment configuration file..."
        cat > .env << EOF
# OpenAI API Key for AI Code Translator
# Replace with your actual API key
OPENAI_API_KEY=your_openai_api_key_here

# Other configuration options
NODE_ENV=production
EOF
        log_warning "Please edit the .env file and add your OpenAI API key before starting the applications."
    fi
    
    # Build and start services
    log_info "Building Docker images..."
    docker-compose build
    
    log_info "Starting services..."
    docker-compose up -d
    
    log_success "Docker applications started successfully!"
    echo
    echo "Access your applications at:"
    echo "- Cloud Monitor: http://localhost:8899"
    echo "- AI Code Translator: http://localhost:3000"
    echo
    echo "To stop the applications, run: docker-compose down"
    echo "To view logs, run: docker-compose logs -f"
}

# Setup guides menu
setup_guides_menu() {
    while true; do
        echo
        echo "Setup Guides:"
        echo "1) MIT Deep Learning Course"
        echo "2) IDE Plugins (InCoder, CodeSeek)"
        echo "3) Laravel OpenAI Wrapper"
        echo "4) Alembic Database Migration Tool"
        echo "5) Development Environment Dotfiles"
        echo "6) Back to main menu"
        echo
        read -p "Choose a setup guide (1-6): " guide_choice
        
        case $guide_choice in
            1)
                log_info "Opening MIT Deep Learning Course setup guide..."
                if command_exists less; then
                    less setup-guides/deep-learning-course/README.md
                else
                    cat setup-guides/deep-learning-course/README.md
                fi
                ;;
            2)
                log_info "Opening IDE Plugins setup guide..."
                if command_exists less; then
                    less setup-guides/ide-plugins/README.md
                else
                    cat setup-guides/ide-plugins/README.md
                fi
                ;;
            3)
                log_info "Opening Laravel OpenAI Wrapper setup guide..."
                if command_exists less; then
                    less setup-guides/laravel-openai/README.md
                else
                    cat setup-guides/laravel-openai/README.md
                fi
                ;;
            4)
                log_info "Opening Alembic setup guide..."
                if command_exists less; then
                    less setup-guides/alembic-setup/README.md
                else
                    cat setup-guides/alembic-setup/README.md
                fi
                ;;
            5)
                log_info "Opening Dotfiles setup guide..."
                if command_exists less; then
                    less setup-guides/dotfiles/README.md
                else
                    cat setup-guides/dotfiles/README.md
                fi
                ;;
            6)
                break
                ;;
            *)
                log_error "Invalid choice. Please select 1-6."
                ;;
        esac
    done
}

# View explanations
view_explanations() {
    log_info "Opening explanations for non-installable repositories..."
    if command_exists less; then
        less explanations/README.md
    else
        cat explanations/README.md
    fi
}

# Install everything
install_everything() {
    log_info "Installing everything..."
    
    # Install Docker apps if possible
    if command_exists docker && command_exists docker-compose; then
        install_docker_apps
    else
        log_warning "Skipping Docker applications (Docker not available)"
    fi
    
    echo
    log_info "Setup guides are available in the setup-guides/ directory."
    log_info "Please follow the individual guides for libraries and plugins."
    
    echo
    log_info "Explanations for non-installable items are available in explanations/README.md"
}

# Create desktop shortcuts (optional)
create_shortcuts() {
    if [ "$1" = "true" ]; then
        log_info "Creating desktop shortcuts..."
        
        # This is a placeholder - actual implementation would depend on the desktop environment
        log_info "Desktop shortcuts would be created here (implementation depends on desktop environment)"
    fi
}

# Main installation function
main() {
    echo "Welcome to the AI/ML Repository Installation Package!"
    echo
    
    # Check if we're in the right directory
    if [ ! -f "README.md" ] || [ ! -d "docker-apps" ]; then
        log_error "Please run this script from the installation package root directory."
        exit 1
    fi
    
    # Check system requirements
    check_requirements
    
    while true; do
        show_menu
        read -p "Enter your choice (1-5): " choice
        
        case $choice in
            1)
                install_docker_apps
                ;;
            2)
                setup_guides_menu
                ;;
            3)
                view_explanations
                ;;
            4)
                install_everything
                ;;
            5)
                log_info "Thank you for using the AI/ML Repository Installation Package!"
                exit 0
                ;;
            *)
                log_error "Invalid choice. Please select 1-5."
                ;;
        esac
        
        echo
        read -p "Press Enter to continue..."
    done
}

# Handle script interruption
trap 'log_warning "Installation interrupted by user"; exit 1' INT TERM

# Run main function
main "$@"

