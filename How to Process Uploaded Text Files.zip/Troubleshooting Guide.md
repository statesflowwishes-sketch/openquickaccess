# Troubleshooting Guide

This comprehensive guide addresses common issues you may encounter when installing and using the AI/ML Repository Installation Package.

## General Installation Issues

### Permission Denied Errors

**Problem**: Getting "Permission denied" errors when running scripts.

**Solution**:
```bash
# Make scripts executable
chmod +x scripts/install.sh
chmod +x scripts/setup-environment.sh

# If still having issues, check file ownership
ls -la scripts/
sudo chown $USER:$USER scripts/*
```

### Missing Dependencies

**Problem**: Script fails with "command not found" errors.

**Solutions**:

1. **For Ubuntu/Debian**:
   ```bash
   sudo apt update
   sudo apt install git curl python3 python3-pip nodejs npm
   ```

2. **For CentOS/RHEL/Fedora**:
   ```bash
   sudo dnf install git curl python3 python3-pip nodejs npm
   ```

3. **For macOS**:
   ```bash
   # Install Homebrew first if not installed
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   
   # Then install dependencies
   brew install git curl python3 node
   ```

### Network Connectivity Issues

**Problem**: Downloads fail or timeout.

**Solutions**:
1. Check internet connection
2. Try using a VPN if behind corporate firewall
3. Configure proxy settings if needed:
   ```bash
   export http_proxy=http://proxy.company.com:8080
   export https_proxy=http://proxy.company.com:8080
   ```

## Docker-Related Issues

### Docker Not Starting

**Problem**: Docker daemon not running.

**Solutions**:

1. **Linux**:
   ```bash
   sudo systemctl start docker
   sudo systemctl enable docker
   ```

2. **macOS**: Start Docker Desktop application

3. **Windows**: Start Docker Desktop application

### Docker Permission Issues

**Problem**: "Permission denied" when running Docker commands.

**Solution**:
```bash
# Add user to docker group (Linux)
sudo usermod -aG docker $USER

# Log out and log back in, or run:
newgrp docker

# Test Docker access
docker run hello-world
```

### Docker Compose Issues

**Problem**: `docker-compose` command not found.

**Solutions**:

1. **Install Docker Compose**:
   ```bash
   # Linux
   sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
   sudo chmod +x /usr/local/bin/docker-compose
   
   # Or use pip
   pip3 install docker-compose
   ```

2. **Use docker compose (newer syntax)**:
   ```bash
   # Instead of docker-compose
   docker compose up -d
   ```

### Container Build Failures

**Problem**: Docker images fail to build.

**Solutions**:

1. **Clear Docker cache**:
   ```bash
   docker system prune -a
   docker builder prune
   ```

2. **Check disk space**:
   ```bash
   df -h
   docker system df
   ```

3. **Rebuild with no cache**:
   ```bash
   docker-compose build --no-cache
   ```

### Port Already in Use

**Problem**: "Port already in use" errors.

**Solutions**:

1. **Find what's using the port**:
   ```bash
   # Linux/macOS
   sudo lsof -i :3000
   sudo lsof -i :8899
   
   # Windows
   netstat -ano | findstr :3000
   ```

2. **Stop conflicting services**:
   ```bash
   # Kill process by PID
   sudo kill -9 <PID>
   
   # Or stop Docker containers
   docker-compose down
   ```

3. **Change ports in docker-compose.yml**:
   ```yaml
   ports:
     - "3001:3000"  # Change host port from 3000 to 3001
   ```

## Application-Specific Issues

### AI Code Translator Issues

**Problem**: Application starts but doesn't work properly.

**Common Causes & Solutions**:

1. **Missing OpenAI API Key**:
   ```bash
   # Edit .env file
   nano .env
   
   # Add your API key
   OPENAI_API_KEY=sk-your-actual-api-key-here
   
   # Restart container
   docker-compose restart ai-code-translator
   ```

2. **Invalid API Key**:
   - Verify key is correct at https://platform.openai.com/api-keys
   - Check if key has sufficient credits
   - Ensure key has proper permissions

3. **Network Issues**:
   ```bash
   # Test API connectivity
   curl -H "Authorization: Bearer YOUR_API_KEY" https://api.openai.com/v1/models
   ```

### Cloud Monitor Issues

**Problem**: Cloud Monitor can't connect to servers.

**Solutions**:

1. **Check configuration**:
   ```bash
   # Edit config file
   nano docker-apps/cloudmonitor/config.yaml
   
   # Verify server details:
   # - Correct hostnames/IPs
   # - Valid usernames/passwords
   # - Correct SSH ports
   ```

2. **Test SSH connectivity**:
   ```bash
   # Test manual SSH connection
   ssh username@hostname -p 22
   ```

3. **Firewall Issues**:
   - Ensure SSH port (22) is open on target servers
   - Check if monitoring server can reach target servers

### Python Environment Issues

**Problem**: Python packages fail to install or import.

**Solutions**:

1. **Virtual Environment Issues**:
   ```bash
   # Create new virtual environment
   python3 -m venv ai-ml-env
   source ai-ml-env/bin/activate  # Linux/macOS
   # or
   ai-ml-env\Scripts\activate     # Windows
   
   # Upgrade pip
   pip install --upgrade pip
   ```

2. **Package Conflicts**:
   ```bash
   # Create requirements.txt with specific versions
   pip freeze > requirements.txt
   
   # Install from requirements
   pip install -r requirements.txt
   ```

3. **Permission Issues**:
   ```bash
   # Install packages for user only
   pip install --user package_name
   
   # Or use virtual environment (recommended)
   ```

### Node.js Issues

**Problem**: npm install fails or Node.js applications won't start.

**Solutions**:

1. **Clear npm cache**:
   ```bash
   npm cache clean --force
   ```

2. **Delete node_modules and reinstall**:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

3. **Node version issues**:
   ```bash
   # Check Node version
   node --version
   
   # Install specific version using nvm
   curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
   nvm install 18
   nvm use 18
   ```

## IDE Plugin Issues

### VS Code Extension Problems

**Problem**: CodeSeek extension not working.

**Solutions**:

1. **Extension not installed**:
   - Open VS Code
   - Go to Extensions (Ctrl+Shift+X)
   - Search for "CodeSeek"
   - Install the extension

2. **API Key not configured**:
   ```
   1. Open VS Code Settings (Ctrl+,)
   2. Search for "CodeSeek"
   3. Enter your DeepSeek API key
   ```

3. **Extension conflicts**:
   - Disable other AI coding extensions temporarily
   - Restart VS Code
   - Re-enable extensions one by one

### JetBrains Plugin Issues

**Problem**: InCoder plugin not appearing or working.

**Solutions**:

1. **Plugin not installed**:
   - File → Settings → Plugins
   - Search for "InCoder"
   - Install and restart IDE

2. **IDE version compatibility**:
   - Check plugin compatibility with your IDE version
   - Update IDE if necessary

3. **Plugin configuration**:
   - Check plugin settings in IDE preferences
   - Verify API configurations if required

## Database Issues (Alembic)

### Migration Failures

**Problem**: Alembic migrations fail.

**Solutions**:

1. **Database connection issues**:
   ```bash
   # Test database connection
   python -c "from sqlalchemy import create_engine; engine = create_engine('your_db_url'); print(engine.execute('SELECT 1').scalar())"
   ```

2. **Migration conflicts**:
   ```bash
   # Check current revision
   alembic current
   
   # Check migration history
   alembic history
   
   # Resolve conflicts
   alembic merge heads -m "merge conflicts"
   ```

3. **Model import issues**:
   ```python
   # In alembic/env.py, ensure models are imported
   from myapp.models import Base
   target_metadata = Base.metadata
   ```

## API Key Issues

### OpenAI API Problems

**Common Issues**:

1. **Rate limiting**:
   - Reduce request frequency
   - Implement exponential backoff
   - Upgrade API plan if needed

2. **Quota exceeded**:
   - Check usage at https://platform.openai.com/usage
   - Add billing information
   - Monitor usage patterns

3. **Invalid requests**:
   - Check API documentation for correct parameters
   - Validate input data
   - Handle error responses properly

### DeepSeek API Problems

**Solutions**:

1. **Account verification**:
   - Ensure account is verified at https://platform.deepseek.com/
   - Check email for verification links

2. **API limits**:
   - Review API usage limits
   - Implement proper rate limiting
   - Consider upgrading plan

## Environment-Specific Issues

### macOS Issues

**Problem**: Permission issues or missing tools.

**Solutions**:

1. **Xcode Command Line Tools**:
   ```bash
   xcode-select --install
   ```

2. **Homebrew issues**:
   ```bash
   # Reinstall Homebrew
   /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
   ```

3. **Python path issues**:
   ```bash
   # Add to ~/.zshrc or ~/.bash_profile
   export PATH="/usr/local/bin:$PATH"
   ```

### Windows WSL Issues

**Problem**: WSL-specific problems.

**Solutions**:

1. **WSL not enabled**:
   ```powershell
   # Run in PowerShell as Administrator
   wsl --install
   ```

2. **File permission issues**:
   ```bash
   # In WSL, fix file permissions
   sudo chmod +x scripts/*.sh
   ```

3. **Network connectivity**:
   - Check Windows firewall settings
   - Ensure WSL can access internet

### Linux Distribution Issues

**Problem**: Package manager differences.

**Solutions**:

1. **Ubuntu/Debian**:
   ```bash
   sudo apt update && sudo apt upgrade
   sudo apt install build-essential
   ```

2. **CentOS/RHEL/Fedora**:
   ```bash
   sudo dnf update
   sudo dnf groupinstall "Development Tools"
   ```

3. **Arch Linux**:
   ```bash
   sudo pacman -Syu
   sudo pacman -S base-devel
   ```

## Performance Issues

### Slow Docker Builds

**Solutions**:

1. **Use .dockerignore**:
   ```
   node_modules
   .git
   *.log
   ```

2. **Multi-stage builds**:
   ```dockerfile
   FROM node:18-alpine AS builder
   # Build stage
   
   FROM node:18-alpine AS runtime
   # Runtime stage
   ```

3. **Build cache optimization**:
   ```bash
   # Use BuildKit
   export DOCKER_BUILDKIT=1
   docker build .
   ```

### High Memory Usage

**Solutions**:

1. **Limit container memory**:
   ```yaml
   # In docker-compose.yml
   services:
     app:
       deploy:
         resources:
           limits:
             memory: 512M
   ```

2. **Optimize applications**:
   - Reduce batch sizes in ML applications
   - Use streaming for large datasets
   - Implement proper garbage collection

## Getting Help

### Log Collection

When reporting issues, collect relevant logs:

```bash
# Docker logs
docker-compose logs > logs.txt

# System logs (Linux)
journalctl -u docker > docker-system.log

# Application-specific logs
tail -f /var/log/application.log
```

### Diagnostic Information

Include this information when seeking help:

```bash
# System information
uname -a
cat /etc/os-release

# Docker information
docker version
docker-compose version

# Python information
python3 --version
pip3 --version

# Node.js information
node --version
npm --version

# Available resources
free -h
df -h
```

### Community Support

1. **GitHub Issues**: Check repository issue trackers
2. **Stack Overflow**: Search for similar problems
3. **Docker Community**: https://forums.docker.com/
4. **Python Community**: https://discuss.python.org/
5. **Node.js Community**: https://github.com/nodejs/help

### Professional Support

For production deployments or complex issues:

1. **Docker Support**: https://www.docker.com/support/
2. **Cloud Provider Support**: AWS, Azure, GCP support channels
3. **Professional Services**: Consider hiring DevOps consultants

## Prevention Best Practices

### Regular Maintenance

1. **Update dependencies regularly**:
   ```bash
   # Update Docker images
   docker-compose pull
   
   # Update Python packages
   pip list --outdated
   pip install --upgrade package_name
   
   # Update Node.js packages
   npm outdated
   npm update
   ```

2. **Monitor resource usage**:
   ```bash
   # System monitoring
   htop
   iotop
   
   # Docker monitoring
   docker stats
   ```

3. **Backup configurations**:
   ```bash
   # Backup important configs
   cp -r ~/.config ~/config-backup-$(date +%Y%m%d)
   ```

### Security Best Practices

1. **Keep API keys secure**:
   - Use environment variables
   - Never commit keys to version control
   - Rotate keys regularly

2. **Update systems regularly**:
   ```bash
   # System updates
   sudo apt update && sudo apt upgrade
   
   # Security updates only
   sudo apt update && sudo apt upgrade -s | grep -i security
   ```

3. **Use least privilege principle**:
   - Don't run containers as root unless necessary
   - Use specific user accounts for services
   - Limit network access where possible

This troubleshooting guide should help you resolve most common issues. If you encounter problems not covered here, please check the individual setup guides for component-specific troubleshooting or seek help from the respective project communities.

