# Quick Start Guide

Get up and running with the AI/ML Repository Installation Package in minutes!

## 🚀 Fastest Path to Success

### Option 1: Docker Applications (5 minutes)

If you have Docker installed, this is the fastest way to get started:

```bash
# 1. Navigate to the package directory
cd installation_package

# 2. Configure API keys (required for AI Code Translator)
cp .env.example .env
nano .env  # Add your OpenAI API key

# 3. Start all applications
docker-compose up -d

# 4. Access your applications
# - Cloud Monitor: http://localhost:8899
# - AI Code Translator: http://localhost:3000
```

### Option 2: Interactive Installation (10 minutes)

For a guided installation experience:

```bash
# 1. Make the script executable
chmod +x scripts/install.sh

# 2. Run the interactive installer
./scripts/install.sh

# 3. Follow the menu prompts
```

## 📋 Prerequisites Check

Before starting, ensure you have:

- [ ] **Operating System**: Linux, macOS, or Windows with WSL
- [ ] **Internet Connection**: For downloading dependencies
- [ ] **Basic Tools**: Git, curl (usually pre-installed)

### Quick Prerequisites Install

**Ubuntu/Debian:**
```bash
sudo apt update && sudo apt install git curl
```

**macOS:**
```bash
# Install Homebrew if not installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install git curl
```

**CentOS/RHEL/Fedora:**
```bash
sudo dnf install git curl
```

## 🔑 API Keys Setup

Several applications require API keys. Get them ready:

### OpenAI API Key (Required for AI Code Translator)
1. Visit https://platform.openai.com/
2. Sign up or log in
3. Go to API Keys section
4. Create a new key
5. Copy the key (starts with `sk-`)

### DeepSeek API Key (Optional, for CodeSeek VS Code extension)
1. Visit https://platform.deepseek.com/
2. Sign up and verify account
3. Generate API key
4. Copy for later use

## 🐳 Docker Quick Setup

### Install Docker (if not installed)

**Ubuntu/Debian:**
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER
# Log out and back in
```

**macOS:**
```bash
brew install --cask docker
# Start Docker Desktop app
```

**Windows:**
Download Docker Desktop from https://www.docker.com/products/docker-desktop

### Start Applications

```bash
# Clone or extract the installation package
cd installation_package

# Configure environment
echo "OPENAI_API_KEY=your_key_here" > .env

# Start services
docker-compose up -d

# Check status
docker-compose ps
```

## 🛠️ Individual Tool Setup

### MIT Deep Learning Course
```bash
# Quick Python environment setup
python3 -m venv mit-dl
source mit-dl/bin/activate
pip install jupyter mitdeeplearning tensorflow

# Clone course materials
git clone https://github.com/abusufyanvu/6S191_MIT_DeepLearning.git
cd 6S191_MIT_DeepLearning
jupyter notebook
```

### VS Code AI Extension (CodeSeek)
1. Open VS Code
2. Press `Ctrl+Shift+X` (Extensions)
3. Search "CodeSeek"
4. Install extension
5. Configure API key in settings

### JetBrains AI Plugin (InCoder)
1. Open your JetBrains IDE
2. Go to `File` → `Settings` → `Plugins`
3. Search "InCoder"
4. Install and restart IDE

## 🔧 Common First-Time Issues

### "Permission Denied" Error
```bash
chmod +x scripts/*.sh
```

### "Docker not found"
```bash
# Install Docker using the commands above
# Or run the environment setup script
./scripts/setup-environment.sh
```

### "Port already in use"
```bash
# Check what's using the port
sudo lsof -i :3000
# Kill the process or change ports in docker-compose.yml
```

### API Key Not Working
- Double-check the key is correct
- Ensure you have credits/quota
- Check for extra spaces or characters

## 📱 What You Get

After successful installation:

### 🌐 Web Applications
- **Cloud Monitor** (localhost:8899): Monitor server resources with a web GUI
- **AI Code Translator** (localhost:3000): Translate code between programming languages

### 🧠 Learning Resources
- **MIT Deep Learning Course**: Jupyter notebooks for hands-on learning
- **Setup Guides**: Step-by-step instructions for various tools

### 🔌 IDE Integrations
- **CodeSeek**: AI assistant for VS Code
- **InCoder**: AI code generation for JetBrains IDEs

### 🛠️ Development Tools
- **Laravel OpenAI Wrapper**: PHP integration for OpenAI APIs
- **Alembic**: Database migration tool for Python
- **Dotfiles**: Consistent development environment configuration

## 🎯 Next Steps

1. **Explore the applications**: Try the web interfaces
2. **Follow setup guides**: For tools you're interested in
3. **Read documentation**: Check individual README files
4. **Join communities**: Connect with other users

## 🆘 Need Help?

- **Troubleshooting**: See `TROUBLESHOOTING.md`
- **Detailed guides**: Check `setup-guides/` directory
- **Issues**: Check GitHub repositories for specific tools

## 🎉 Success Indicators

You'll know everything is working when:

- [ ] Docker containers are running: `docker-compose ps`
- [ ] Web apps are accessible in your browser
- [ ] No error messages in logs: `docker-compose logs`
- [ ] API calls work (test with a simple code translation)

## ⚡ Pro Tips

1. **Bookmark the applications** for easy access
2. **Set up aliases** for common commands:
   ```bash
   echo "alias ai-start='cd ~/installation_package && docker-compose up -d'" >> ~/.bashrc
   echo "alias ai-stop='cd ~/installation_package && docker-compose down'" >> ~/.bashrc
   ```
3. **Monitor resource usage** with `docker stats`
4. **Keep API keys secure** - never share or commit them

Happy coding with AI! 🚀

