# AI/ML Repository Installation Package

This package provides a comprehensive installation solution for the AI/ML repositories you specified. Due to the diverse nature of these repositories, we've organized them into different categories with appropriate installation methods.

## Package Structure

```
installation_package/
├── README.md                    # This file
├── docker-apps/                 # Docker-based standalone applications
│   ├── cloudmonitor/           # Web-GUI Monitor for Linux Servers
│   └── ai-code-translator/     # AI-powered code translator
├── setup-guides/               # Detailed setup guides for libraries/plugins
│   ├── deep-learning-course/   # MIT 6.S191 Deep Learning Course
│   ├── ide-plugins/           # IDE plugins (InCoder, CodeSeek)
│   ├── laravel-openai/        # Laravel OpenAI wrapper
│   ├── alembic-setup/         # Database migration tool
│   └── dotfiles/              # Development environment configuration
├── explanations/              # Information about non-installable entries
├── scripts/                   # Installation and utility scripts
└── docker-compose.yml         # Orchestration for Docker applications
```

## Quick Start

### Option 1: Docker-based Applications (Recommended)
For the standalone applications that can be fully containerized:

```bash
# Navigate to the package directory
cd installation_package

# Start all Docker applications
docker-compose up -d

# Access applications:
# - Cloud Monitor: http://localhost:8899
# - AI Code Translator: http://localhost:3000
```

### Option 2: Individual Setup
Follow the detailed guides in the `setup-guides/` directory for each repository you're interested in.

### Option 3: Automated Setup Script
Run the master installation script:

```bash
./scripts/install.sh
```

## Repository Categories

### 🐳 Docker-based Applications (Fully Functional)
- **cloudmonitor**: Web-GUI Monitor for Academic Linux Servers
- **ai-code-translator**: AI-powered code translation tool

### 📚 Setup Guides (Require Host Environment)
- **6S191_MIT_DeepLearning**: MIT Deep Learning course materials
- **incoder-plugin**: JetBrains IDE plugin for code generation
- **CodeSeek**: VS Code extension for AI-powered coding assistance
- **open-ai**: Laravel wrapper for OpenAI API
- **lembic (Alembic)**: Database migration tool for Python
- **dotfiles**: Cross-platform development environment configuration

### ℹ️ Information Only
- **OpenAI-Demo**: iOS application (requires macOS + Xcode)
- **OpenAI-API-Reference-Guide**: Collection of API documentation links
- **python-devops**: DevOps learning course (multiple tool setup required)
- **Docker-with-AWS-Cloud9**: Tutorial for AWS Cloud9 environment
- **boxci**: Archived project (no longer maintained)
- **Reasonance-Copilot**: Repository not found
- **ollama-assistant**: Repository not found
- **ai-ml-course**: Repository not found

## Prerequisites

### For Docker Applications
- Docker and Docker Compose installed
- At least 4GB of available RAM
- Internet connection for downloading images

### For Manual Setup
- Varies by repository (see individual setup guides)
- Common requirements: Python 3.8+, Node.js 16+, Git

## API Keys Required

Several applications require API keys:
- **OpenAI API Key**: For ai-code-translator and related tools
- **DeepSeek API Key**: For CodeSeek extension
- **Google Gemini API Key**: For predictifyAI-Codelab

Instructions for obtaining these keys are provided in the respective setup guides.

## Support and Troubleshooting

Each setup guide includes:
- Detailed installation steps
- Common issues and solutions
- Configuration examples
- Usage instructions

For issues with this installation package, check the troubleshooting section in each guide.

## License

This installation package is provided as-is. Individual repositories maintain their own licenses. Please refer to each repository's license file for specific terms.

